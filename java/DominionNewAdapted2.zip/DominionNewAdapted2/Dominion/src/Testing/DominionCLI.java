package Testing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import DominionCardGame.CardFunctions;
import DominionCardGame.DatabaseHelper;
import DominionCardGame.MainGame;
import DominionCardGame.VoorraadDeck;

public class DominionCLI {
	private int numberOfPlayers;
	private ArrayList<String> gameModes;
	private DatabaseHelper b;
	private String chosenGameMode;
	private ArrayList<String> playerNames;
	private MainGame m;
	private CardFunctions cf;
	
	public DominionCLI()
	{
		b = new DatabaseHelper();
		askHowManyPlayers();
		addPlayers(numberOfPlayers);
		askForGameMode();
		m = new MainGame(chosenGameMode,playerNames);
		showVoorraadStapelsMetAantal();
		cf = new CardFunctions();
	}
	
	
	public void showVoorraadStapelsMetAantal()
	{
		System.out.println("Volgende kaarten bevinden zich in de voorraad met volgende aantallen:\n");
		Iterator it = m.getVoorraadBuild().getVoorraad().entrySet().iterator();
	    while (it.hasNext()) {
	        HashMap.Entry pair = (HashMap.Entry)it.next();
	        
	        String kaartnaam = pair.getKey().toString();
	        VoorraadDeck v = (VoorraadDeck) pair.getValue();
	        int aantal = v.getAantalKaartenInVoorraad();
	        System.out.println(kaartnaam + " " + aantal);
	        
	        
	}}
	
	public void askToPlayAction(Player playerOnTurn)
	{
		System.out.println("Wenst u een actiekaart te spelen?");
		Scanner input = new Scanner(System.in);
		String actionYesNo = input.nextLine();
		(actionYesNo.equals("Yes")? cf.callFunctions(askAction(),playerOnTurn)): buyPhase());
		
	}
	public void buyPhase()
	{
		
	}
	public askAction()
	{
		Scanner input = new Scanner(System.in);
		String action = input.nextLine();
	}
	public void askForGameMode()
	{
		System.out.println("Choose one of the following gameModes");
		gameModes = b.SelectWithoutWhere("modenaam","gamemodes");
		System.out.println(gameModes);
		for (int i =1;i>gameModes.size();i++)
		{
			int cipher = i+1;
			System.out.println(cipher + " " + gameModes.get(i));
		}
		Scanner input = new Scanner(System.in);
		String gamemode = input.nextLine();
		chosenGameMode = gamemode;
		
		
	}
	
	public void askHowManyPlayers()
	{
		System.out.println("Met hoeveel willen jullie spelen?");
		Scanner input = new Scanner(System.in);
		numberOfPlayers = Integer.parseInt(input.nextLine());
	}
	
	public void addPlayers(int aantalSpelers)
	{
		playerNames = new ArrayList<String>();
		System.out.println("Geef jullie naam op aub");
		for(int i = 0;i<aantalSpelers;i++)
		{
			Scanner input = new Scanner(System.in);
			String naamSpeler = input.nextLine();
			playerNames.add(naamSpeler);
			
		}
	}
	public static void main(String[] args) 
	{
		DominionCLI d = new DominionCLI();
		
	}
}
