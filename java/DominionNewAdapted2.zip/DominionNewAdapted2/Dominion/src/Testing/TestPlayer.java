package Testing;

import java.util.ArrayList;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.Player;
import DominionCardGame.VoorraadBuild;

public class TestPlayer {
	private Player p;
	private VoorraadBuild v;
	private DatabaseHelper d;
	private ArrayList<String> cardsInGamemode;
	private String name;
	private int actions;
	private int purchases;
	private Deck drawDeck;
	private Deck discardDeck;
	//private Hand hand;
	private Deck hand;
	private int moneyTurn; //hoeveel dat persoon kan spenderen in 1 beurt
	
	
	public TestPlayer()
	{
		setup();
		
	}
	
	
	public void checkName()
	{
		if (!this.name.equals(p.getSpelerNaam()))
		{
			
			System.out.println("Spelersnaam niet goed verwerkt");
		}
	}
	
	public void checkDecks(Deck verwachtDeck,Deck deckPlayer)
	{
		if (!(verwachtDeck.equals(deckPlayer)))
		{
			System.out.println("fout in DeckSetup");
		}
	}
	
	public void checkNumberValues(int verwachtGetal,int playerGetal)
	{
		if (verwachtGetal != playerGetal)
		{
			System.out.println("fout in getalToekenning");
		}
	}
	
	public void checkSetupPlayer()
	{
		
	}
	public void setup(){
		d = new DatabaseHelper();
		cardsInGamemode = d.SelectCardsMatchingChosenDeck("Big Money");
		v = new VoorraadBuild(cardsInGamemode,d,2);
		p = new Player("Bert",v);
		
		
		
		this.name = "Bert";
		this.drawDeck = new Deck(v);
		this.discardDeck = new Deck(v);
		this.hand = new Deck(v);
		
		
		
		
		this.actions = 1;
		this.purchases = 1;
		this.moneyTurn = 0;
		
		
	}
	public void testSetupPlayer()
	{
		int EstateKaartenInVoorraad = v.getVoorraadDeck("Estate").getAantalKaartenInVoorraad();
		int CopperKaartenInVoorraad = v.getVoorraadDeck("Copper").getAantalKaartenInVoorraad();
		Player p1 = new Player("Jan",v);
		if ((v.getVoorraadDeck("Estate").getAantalKaartenInVoorraad() != EstateKaartenInVoorraad - 3 ) && (v.getVoorraadDeck("Copper").getAantalKaartenInVoorraad() != CopperKaartenInVoorraad - 7 ))
		{
			System.out.println("Kaarten uit voorraad toewijzen aan hand speler werkt niet");
		}
		
		
	}
	
	
	
	public void testVoorraadAantalEstateKaart(int aantalVerwachteKaarten, String cardname)
	{
		int aantalKaartenExpected = aantalVerwachteKaarten;
		if (aantalKaartenExpected != v.getVoorraadDeck(cardname).getAantalKaartenInVoorraad())
		{
			System.out.println("aantalKaartenInVoorraad klopt niet met database");
		}
	}
	
	
	
	
	public void TestKaartenInDrawDeck(int verwachteKaarten,int kaartenInDrawDeck)
	{
		
		if (kaartenInDrawDeck !=  verwachteKaarten)
		{
			System.out.println(kaartenInDrawDeck);
			System.out.println("setup werkt niet");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestPlayer tp = new TestPlayer();
		tp.TestKaartenInDrawDeck(10,tp.p.getPlayerDrawDeck().getSizeDeck());
		tp.testVoorraadAantalEstateKaart(21, "Estate");
		tp.testVoorraadAantalEstateKaart(53, "Copper");
		tp.checkName();
		System.out.println(tp.discardDeck.equals(tp.p.getPlayerDiscardDeck()));
		System.out.println(tp.hand.equals(tp.p.getPlayerHand()));
		tp.checkDecks(tp.discardDeck, tp.p.getPlayerDiscardDeck());
		tp.checkDecks(tp.hand, tp.p.getPlayerHand());
		tp.checkNumberValues(tp.moneyTurn, tp.p.getMoneyLeftToSpend());
		tp.checkNumberValues(tp.actions, tp.p.getActions());
		tp.checkNumberValues(tp.purchases, tp.p.getPurchases());
		tp.testSetupPlayer();
		
	}
}
