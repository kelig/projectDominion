package Testing;

import java.util.ArrayList;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.Player;
import DominionCardGame.VoorraadBuild;

public class TestBuy {
	private DatabaseHelper d;
	private Player p1;
	private Player p2;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenInVoorraad;
	
	public TestBuy()
	{
		setup();
	}
	public void setup()
	{
		d = new DatabaseHelper();
		kaartenInVoorraad = d.SelectCardsMatchingChosenDeck("Big Money");
		vb = new VoorraadBuild(kaartenInVoorraad,d,2);
		p1 = new Player("Bert",vb);
		p2 = new Player("Stijn",vb);
		
		
	}
	
	/*public void NietGenoegGeld()
	{
		p1.SetMoneyTurn(1);
		p1.ControlBuyCard("Gold");
		Deck playerDrawDeck = p1.getPlayerDrawDeck();
		if (playerDrawDeck.getCard(playerDrawDeck.getSizeDeck()).getCardname() == "Gold")
		{
			System.out.println("Player mag geen kaarten kunnen kopen die meer kosten dan het geld die hij kan spenderen");
		}

	
	}
	public void geenBuyActionsMeerOVer()
	{
		p1.setBuyActions(0);
		p1.ControlBuyCard("Copper");
		Deck playerDrawDeck = p1.getPlayerDrawDeck();
		if (playerDrawDeck.getCard(playerDrawDeck.getSizeDeck()).getCardname() == "Copper")
		{
			System.out.println("Player mag geen kaarten kunnen kopen als z'n acties op zijn");
		}
	}*/
	
	public void ControlBuy(String what,String cardToBuy)
	{
		switch(what)
		{
		case "noBuysLeft":
			p1.setBuyActions(0);
			break;
		case "notEnoughMoney":
			p1.SetMoneyTurn(1);
			break;
		case "StockEmpty":
			vb.getVoorraadDeck(cardToBuy).setStapelVol(false);
			break;
		}
		p1.ControlBuyCard(cardToBuy);
		Deck playerDiscardDeck = p1.getPlayerDiscardDeck();
		//System.out.println(playerDrawDeck);
		//System.out.println(playerDrawDeck.getSizeDeck());
		if (playerDiscardDeck.getCard(playerDiscardDeck.getSizeDeck()-1).getCardname() == cardToBuy)
		{
			System.out.println("Buy Ftie werkt niet");
		}
		
	}
	
	/*public void VoorraadDeckGekozenKaartLeeg()
	{
		
	}*/
	public static void main(String[] args) 
	{
		TestBuy tb = new TestBuy();
		tb.ControlBuy("noBuysLeft","Copper");
		tb.ControlBuy("notEnoughMoney", "Gold");
		tb.ControlBuy("stockEmpty", "Bronze");
			
		
	}

}
