package Testing;

import java.util.ArrayList;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.Player;
import DominionCardGame.VoorraadBuild;

public class TestBuy {
	private DatabaseHelper d;
	private Player p1;
	private Player p2;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenInVoorraad;
	
	public void setup()
	{
		d = new DatabaseHelper();
		p1 = new Player("Bert",vb);
		p2 = new Player("Stijn",vb);
		kaartenInVoorraad = d.SelectCardsMatchingChosenDeck("Big Money");
		vb = new VoorraadBuild(kaartenInVoorraad,d,2);
	}
	
	public void NietGenoegGeld()
	{
		p1.SetMoneyTurn(1);
		p1.ControlBuyCard("Gold");
		Deck playerDrawDeck = p1.getPlayerDrawDeck();
		if (playerDrawDeck.getCard(playerDrawDeck.getSizeDeck()).getCardname() == "Gold")
		{
			System.out.println("Player mag geen kaarten kunnen kopen die meer kosten dan het geld die hij kan spenderen");
		}

	
	}
	public void geenBuyActionsMeerOVer
	public void VoorraadDeckGekozenKaartLeeg
	

}
