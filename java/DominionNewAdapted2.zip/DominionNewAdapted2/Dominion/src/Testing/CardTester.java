package Testing;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.junit.*;

import DominionCardGame.Card;
import DominionCardGame.DatabaseHelper;

public class CardTester {
	private String name;
	private String value;
	private String price;
	private String type;
	private String points;
	private ArrayList<String> cardInfo;
	private HashMap<String,String> kaartInfo;
	private DatabaseHelper database;
	
	public CardTester()
	{
		
		kaartInfo = new HashMap<String,String>();
		database = new DatabaseHelper();
		checkCardValues();
		
	}
	
	public void checkCardValues()
	{
		name = "Adventurer";
		value = "3"; //bij ophalen omgezet naar intiger met : Integer.parseInt()
		price = "6";; //
		type = "Action";
		points = "0";
		cardInfo = new ArrayList<String>(Arrays.asList(name,value,price,type,points));
		//System.out.println(cardInfo);
		kaartInfo.put("points","0");
		kaartInfo.put("TYPE",type);
		kaartInfo.put("price","6");
		kaartInfo.put("VALUE","3");
		kaartInfo.put("kaartnaam",name);
		HashMap<String,String> kaartInfoOpgehaald = database.SelectInfoWithColumnName("*","kaartnaam","kaarten","Adventurer");
		Card Adventurer = new Card("Adventurer",kaartInfoOpgehaald);
		if (!Adventurer.getCardname().equals(kaartInfoOpgehaald.get("kaartnaam")))
		{
			System.out.println("kaartnaam klopt niet");
		}
		if (!(Adventurer.getPrice() == Integer.parseInt(kaartInfoOpgehaald.get("prijs"))))
		{
			System.out.println("prijs kaart klopt niet");
		}
		if (!Adventurer.getType().equals(kaartInfoOpgehaald.get("kaarttype")))
		{
			System.out.println("kaarttype klopt niet");
		}
		if (!(Adventurer.getValue() == Integer.parseInt(kaartInfoOpgehaald.get("waarde"))))
		{
			System.out.println("waarde kaart klopt niet");
		}
		if (!(Adventurer.getPunten() == Integer.parseInt(kaartInfoOpgehaald.get("punten"))))
		{
			System.out.println("puntenAantal op kaart klopt niet");
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CardTester c = new CardTester();
		
	}
	
}
