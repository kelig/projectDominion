package Testing;

public class MainTester {
	private CardTester ct;
	private checkPlayerSession cps;
	private DeckTester dt;
	
	private TestBuy tb;
	private TestDataBaseHelper tdbh;
	private TestPlayer tp;
	private TestVoorraadDeck tvd;
	
	public MainTester()
	{
		ct = new CardTester();
		cps = new checkPlayerSession();
		dt = new DeckTester();
		tb = new TestBuy();
		tdbh = new TestDataBaseHelper();
		tp = new TestPlayer();
		tvd = new TestVoorraadDeck(2);
		tvd.testing();
	}
	
	public static void main(String[] args) 
	{
		MainTester mt = new MainTester();
	}
	
	
}
