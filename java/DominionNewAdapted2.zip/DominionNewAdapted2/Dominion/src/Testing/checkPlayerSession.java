package Testing;

import java.util.ArrayList;
import java.util.Arrays;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadBuild;

public class checkPlayerSession {

	private PlayerSession ps;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenInMode;
	private DatabaseHelper d;
	private ArrayList<String> spelers;
	
	public checkPlayerSession()
	{
		setup();
		
	}
	public void setup()
	{
		d = new DatabaseHelper();
		kaartenInMode = new ArrayList<String>(Arrays.asList("Adventurer","Bureaucrat","Copper","Estate"));//estate en copper moeten er zeker in ,omdat deze in drawDeck spelers gezet worden bij setup van speler
		vb = new VoorraadBuild(kaartenInMode,d,2);
		spelers = new ArrayList<String>(Arrays.asList("Bert","Kevin"));
		ps = new PlayerSession(vb,spelers);
		
		
	}
	
	
	public void checkCreatePlayers(/*ArrayList<String> verwachteSpelers*/)
	{
		ArrayList<String> verwachteSpelers = new ArrayList<String>(Arrays.asList("Bert","Kevin"));
		
		if (ps.getSpelersInSpel().size() != 2)
		{
			System.out.println("aantal spelers toegevoegd klopt niet");
		}
		
		/*if (ps.getSpelersInSpel().get(0).getSpelerNaam() != "Bert" && ps.getSpelersInSpel().get(1).getSpelerNaam() != "Kevin")
		{
			System.out.println("spelers niet juist aangemaakt");
		}*/
		for (int i = 0;i<verwachteSpelers.size();i++)
		{
			if (ps.getSpelersInSpel().get(i).getSpelerNaam() != verwachteSpelers.get(i))
					{
				System.out.println("Spelers niet juist aangemaakt");
					}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkPlayerSession cps = new checkPlayerSession();
		
		cps.checkCreatePlayers();
		
}}
