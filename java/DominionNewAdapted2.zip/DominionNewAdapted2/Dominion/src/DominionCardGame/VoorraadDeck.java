package DominionCardGame;

import java.util.HashMap;

public class VoorraadDeck {
	private String nameCardsInPile;
	private int aantal;
	private Card cardConstructor;
	private boolean stapelVol;
	
	private HashMap<String,String> cardInfo;
	public VoorraadDeck(String nameCardsInPile,DatabaseHelper database)
	{
		
		cardInfo = database.SelectInfoWithColumnName("*", "kaartnaam", "kaarten", nameCardsInPile);
		this.nameCardsInPile = nameCardsInPile;
		this.aantal = Integer.parseInt(cardInfo.get("aantalInVoorraad"));
		this.cardConstructor = new Card(nameCardsInPile,cardInfo);
		this.stapelVol = true;
		
		
		
	}
	
	public Card GetCard()
	{
		return this.cardConstructor;
	}

	
	public String getKaartnaam() // vraag naam van kaarten in een voorraadDeck
	{
		return this.nameCardsInPile;
	}
	
	
	public int getAantalKaartenInVoorraad() //vraag aantal kaarten in voorraadStapel van een bepaalde kaart
	{
		return this.aantal;
	}
	
	public Card getCardConstructor() //bij verwijzing naar een kaart, gaat het aantal keer dat die kaart kan gekocht/naar verwezen worden met ��ntje omlaag
	{
		this.aantal-=1;
		if (aantal == 0)
		{
			stapelVol = false;
		}
		return this.cardConstructor;
	}
	
	public boolean getStapelVol() //kijk of er nog kaarten in een stapel van een bepaalde kaart in de voorraad al dan niet leeg is.
	{
		return this.stapelVol;
	}
	
	public static void main(String[] args)
	{
		DatabaseHelper d = new DatabaseHelper();
		VoorraadDeck dk = new VoorraadDeck("Copper",d);
		System.out.println(dk.cardInfo);
	}
}
