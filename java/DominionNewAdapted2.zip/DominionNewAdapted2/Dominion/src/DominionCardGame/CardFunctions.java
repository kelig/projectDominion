package DominionCardGame;

import java.util.ArrayList;

public class CardFunctions {
	private ArrayList<Card> cardsOnField;
	private Player currentPlayer;
	private VoorraadBuild vb;
	private ArrayList<Player> players;
	private ArrayList<Card> cardsToReveal;
	private Deck trashPile;
	private Card cardToPlay;

	public CardFunctions(VoorraadBuild vb,ArrayList<Player> players, ArrayList<Card> cardsOnField,ArrayList<Card> cardsToReveal,Deck trashPile)
	{
		this.vb = vb;
		this.players = players;
		this.cardsOnField = cardsOnField;
		this.cardsToReveal = cardsToReveal;
		this.trashPile = trashPile;
		CardFunctions f = new CardFunctions(vb,players,cardsOnField,cardsToReveal,trashPile);
	}

	public void callFunctions(Card cardToPlay, Player currentPlayer)
	{
		this.currentPlayer = currentPlayer;
		String cardname = cardToPlay.getCardname();
		switch(cardname)
		{
		case "Cellar":
			break;
		case "Chapel":
			break;
		case "Workshop":
			break;
		case "Chancellor":
			break;
		case "Village":
			break;
		case "Woodcutter":
			break;
		case "Feast":
			break;
		case "Militia":
			break;
		case "Moneylender":
			break;
		case "Remodel":
			break;
		case "Bureaucrat":
			break;
		case "Smithy":	
			break;
		case "Spy":
			break;
		case "Thief":
			break;
		case "Throne Room":
			break;
		case "Moat":
			break;
		case "Council Room":
			break;
		case "Festival":
			break;
		case "Laboratory":
			break;
		case "Library":
			break;
		case "Market":
			break;
		case "Mine":
			break;
		case "Witch":
			break;
		case "Adventurer":
			break;
		case "Gardens":
			break;
		}}
	
		/*public void ActionAdventurer(Player p, Deck gewenstDeckVanTeNemen){
			int revealedTreasureCards = 0;
			for (int i = 0;i<gewenstDeckVanTeNemen.getDeck().size();i++)
			{
				while (revealedTreasureCards < 2)
				{
					if (gewenstDeckVanTeNemen.getCard(gewenstDeckVanTeNemen.size()-1).getType() == "Treasure")
					{
						revealedTreasureCards+=1;
					}
					MainGame.RevealCard(p,gewenstDeckVanTeNemen);
				}
		}
		
	}*/
	//hieronder alle fties van kaarten schrijven
	/*public void BureaucratAction(Player current)
	{
		current.getPlayerDrawDeck().addCard(vb.getVoorraadDeck("Silver").getCardConstructor());
		for (int i = 0;i<players.size();i++)
		{
			Player somePlayer = players.get(i);
			if (somePlayer != current)
			{
				if (somePlayer.getPlayerHand().containsCard("Victory"))
				{
				Card VictoryCardOfSomePlayer = somePlayer.getPlayerHand().getCard("Victory");
				cardsToReveal.add(VictoryCardOfSomePlayer);
				cardsToReveal.remove(VictoryCardOfSomePlayer);
				somePlayer.getPlayerDrawDeck().addCard(VictoryCardOfSomePlayer);
				}
				
			}
			else
			{
				//addCardsTo(AraryList<Card> cardsToReplace,ArrayList<Card> from,ArrayList<Card> to)
				addCardsTo(somePlayer.getPlayerHand(),somePlayer.getPlayerHand(),cardsToReveal);
				addCardsTo(cardsToReveal,cardsToReveal,somePlayer.getPlayerHand());
				cardsToReveal.clear();
				
				
			}
		}
	}*/
	
	public void CellarAction(Player current)
	{
		current.updateActions(vb.getVoorraadDeck("Cellar").GetCard().getExtraActions());
	}
	
	public void ChancellorAction(Player current)
	{
		current.addMoneyToSpend(2);
		for (int i = 0;i<current.getPlayerDrawDeck().getSizeDeck();i++)
		{
			Card cardToAdd = current.getPlayerDrawDeck().getCard(i);
			current.getPlayerDrawDeck().remove(cardToAdd);
			current.getPlayerDiscardDeck().add(cardToAdd);
		}
		
	}
	
	public void ChapelAction(Card selectedCard,Player current)
	{
		trashPile.add(selectedCard);
		current.getPlayerHand().remove(selectedCard);
		
	}
	
	public void CouncilRoomAction(Player current)
	{
		int cardsToDraw = vb.getVoorraadDeck("Council Room").GetCard().getExtraCards();
		current.drawCards(cardsToDraw);
		current.updatePurchases(vb.getVoorraadDeck("Council Room").GetCard().getExtraBuys());
			
	}
	
	public void drawCards(Player current,int numberDraw)
	{ 
		current.drawCards(numberDraw);															
	}
	
	public void FeastAction(Player current,String cardToBuy)
	{
		//trashPile.add(current.getPlayerHand().getCardWithName("Feast"));
		trashPile.add(cardToPlay);
		int priceCardToBuy = vb.getVoorraadDeck(cardToBuy).GetCard().getPrice();
		if ( priceCardToBuy <= 5)
		{
			current.SetMoneyTurn(priceCardToBuy);
			current.ControlBuyCard(cardToBuy);
		}	
	}
	
	public void FestivalAction(Player current)
	{
		Card festival = vb.getVoorraadDeck("Festival").GetCard();
		current.updateActions(festival.getExtraActions());
		current.updatePurchases(festival.getExtraBuys());
		current.SetMoneyTurn(festival.getExtraCoins());
	}
	
	public void GardensAction(Player current)
	{
		
	}
	
	
	
	
	
		
	
}