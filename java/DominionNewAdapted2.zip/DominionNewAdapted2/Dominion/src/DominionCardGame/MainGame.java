package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class MainGame {
	private DatabaseHelper b;
	private ArrayList<String> voorraad;
	private VoorraadBuild v;
	private ArrayList<String> gameModes;
	private String chosenGameMode;
	private PlayerSession p;
	private ArrayList<Card> playCardsOnField;
	private CardFunctions cf;
	private ArrayList<Card> cardsToShow;
	private ArrayList<Card> trashPile;
	
	
	
	
	public MainGame(String chosenGameMode,ArrayList<String> spelersNamen)
	{//gekozen 
		b = new DatabaseHelper();
		voorraad = b.SelectCardsMatchingChosenDeck(chosenGameMode); //dit alleen als men een vast deck kiest, zoniet moet de arraylist met de gekozen kaarten meegegeven
		//worden met constructor die de kaarten bevat die een speler gekozen heeft, gecre�erd;
		setup(spelersNamen);
		
	}
	public MainGame(ArrayList<String> gekozenKaarten,ArrayList<String> spelersNamen)
	{
		b = new DatabaseHelper();
		voegGekozenKaartenToeAanLijst(gekozenKaarten);
		setup(spelersNamen);
		
	}
	public void setup(ArrayList<String> spelers)
	{
		
		v = new VoorraadBuild(voorraad,b,spelers.size());
		p = new PlayerSession(v,spelers);
		//kaartenOpVeld = new ArrayList<Card>();
	}
	public void voegGekozenKaartenToeAanLijst(ArrayList<String> gekozenKaarten)
	{
		voorraad = new ArrayList<String>(Arrays.asList("Copper","Silver","Gold","Estate","Duchy","Province"));
		for (int i = 0;i<gekozenKaarten.size();i++)
		{
			voorraad.add(gekozenKaarten.get(i));
		}
	}
	
	/*public setup()
	{
		
	}*/
	/*public void RevealCard(Player p,Deck deckWaarvanJeKaartenRevealt)
	{
		Card CardOnTopOfDeck = p.getPlayerDrawDeck().getCard(p.getPlayerDrawDeck().getSizeDeck()-1);
		kaartenOpVeld.add(CardOnTopOfDeck);
		deckWaarvanJeKaartenRevealt.ReduceDeckSize();
		
	}*/
	
	public VoorraadBuild getVoorraadBuild()
	{
		return v;
	}
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> spelersNamen = new ArrayList<String>(Arrays.asList("Bert","Karel"));
		ArrayList<String> kaartenGekozen = new ArrayList<String>(Arrays.asList("Adventurer","Bureaucrat"));
		//MainGame m = new MainGame("Big Money",spelersNamen);
		MainGame m = new MainGame(kaartenGekozen,spelersNamen);
		System.out.println(m.voorraad);
		m.v = new VoorraadBuild(m.voorraad,m.b,spelersNamen.size());
		//m.getCardsInVoorraad();
		System.out.println(m.v.getVoorraad());
	}
	
	

}
