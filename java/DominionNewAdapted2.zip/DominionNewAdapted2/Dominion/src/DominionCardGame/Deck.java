package DominionCardGame;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	private ArrayList<Card> deck;
	private VoorraadBuild vb;
	
	public Deck(VoorraadBuild vb)
	{
		this.vb = vb;
		deck = new ArrayList<Card>();
	}


	public Card getCards()
	{
		int decksize = deck.size();
		Card teReturnenKaart = deck.get(decksize);
		deck.remove(decksize);
		return teReturnenKaart;
		
	}
	public ArrayList<Card> getDeck()
	{
		return this.deck;
	}
	
	public void add(Card currentCard)
	{
		deck.add(currentCard);
	}
	public void remove(Card currentCard)
	{
		deck.remove(currentCard);
	}
	
	public void removeTopCard()
	{
		deck.remove(deck.size()-1);
	}
	
	public Card getCardOnTop()
	{
		return deck.get(deck.size()-1);
	}
	
	public Card getCardWithName(String name)
	{
		for (int i = 0;i<deck.size();i++)
		{
			Card huidigeKaart = deck.get(i);
			if (huidigeKaart.getCardname() == name)
			{
				deck.remove(huidigeKaart);
				return huidigeKaart;
			}
		
		}
		return null;
	}
	
	
	/*gebruikt in CardFunctions bij bureaucrat => nog te herzien
	public void addCardsTo(ArrayList<Card> cardsToReplace,ArrayList<Card> from, ArrayList<Card> to)
	{
		for (int i = 0;i<cardsToReplace();i++)
		{
			Card currentCard = cardsToReplace.get(i);
			from.remove(currentCard);
			to.add(currentCard);
		}
	}
	
	public void removeCards(ArrayList<Card> chosenCards)
	{
		for 
	}*/
	
	
	
	
	
	
	public void setupPlayer() //bij aanmaken speler krijgt hij bij start van spel 7 copper en 3 estate kaarten in z'n drawDeck
	{
		for(int y =0; y<7;y++){
			
			
			deck.add(vb.getVoorraadDeck("Copper").getCardConstructor());
	
		}
		for(int z =0; z<3;z++){
	
	
			deck.add(vb.getVoorraadDeck("Estate").getCardConstructor());
	}
		Collections.shuffle(deck);;
}	
	
	public void addCard(Card CardToAdd) //voeg kaart toe aan deck
	{
		deck.add(CardToAdd);
	}
	
	public int getSizeDeck() //vraag lengte van deck op
	{
		return deck.size();
	}
	public void Shuffle() // shuffle je deck
	{
		Collections.shuffle(deck);
	}
	public Card getCard(int index) //vraag een kaart uit je deck op die zich op een bepaalde index in je deck bevind,te gebruiken bij drawCards om laatste kaart op te vragen
	{
		return deck.get(index);
	}
	
	public void RemoveCard(int index)//verwijder kaart uit deck, gebruikt om na draw cards ,wanneer kaart aan hand is toegevoegd, om deze uit je drawdeck te verwijderen
	{// verwijzing naar kaart in voorraad verleg je van vb je drawDeck naar je hand.
		deck.remove(index);
	}
	
	
	public void printDeck() // druk kaarten uit je deck af
	{
		for (int i=0;i<deck.size();i++)
		{
			System.out.print(deck.get(i)/*.getCardname()*/+" = ");
			System.out.println(deck.get(i).getCardname());
		}
		System.out.println();
	}
	
	/*public void RevealCards()
	{
		ArrayList<Card> kaartenOpSpeelveld = new ArrayList<Card>();
		
	}*/
	
	public void ReduceDeckSize()
	{
		deck.remove(getSizeDeck());//verwijdert bovenste kaart vh deck en hierdoor vermindert de size met 1
		
	}
	
	public void BuyCards(String Cardname)
	{
		deck.add(vb.getVoorraadDeck(Cardname).getCardConstructor());
		
	}
	
}
