package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class gameController {
	private MainGame m;



	public gameController(String deckname,ArrayList<String> playernames)
	{
		m = new MainGame(deckname,playernames);
		
	}
public void playTurn(Player current)
{
	current.updateActions(1);
	current.updatePurchases(1);
	current.setSpelerAanZetOfNiet(true);
	Boolean keepBuying = true;
	Boolean keepPlayingActions = true;
	current.drawCards(5);
	current.determineCoinsInHandToSpend();
	
	while (current.getActions() != 0 && keepPlayingActions == true)
	{
		if (YesOrNoTurnBuyAction("Do you wanna play an actioncard ? yes or no ?"))
		{
			
			m.getCardFunctions().playCard(WhichCardToPlayBuy("play"), current);
		}
		else
		{
			keepPlayingActions = false;
		}
	}
	while (current.getPurchases() != 0 && keepBuying == true)	{
		System.out.println("You can still spend " + current.getMoneyLeftToSpend() +  " coins!");
		if(YesOrNoTurnBuyAction("Do you wanna buy a card ? yes or no ?"))
		{
			current.ControlBuyCard(WhichCardToPlayBuy("buy"));	
			
		}
		else
		{
			keepBuying = false;
		}	
		
		}
	current.discardHand();
	current.setBuyActions(0);
	current.setActions(0);
}

public boolean YesOrNoTurnBuyAction(String message)
{
	System.out.println(message);
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	boolean respons = (input.equals("yes"))?true:false;
	return respons;
	
	
}

public String WhichCardToPlayBuy(String actionBuy)
{
	System.out.println("Which card do you wanna " + actionBuy + " ?");
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	return input;	
}

public MainGame getGame()
{
	return m; 
}

public static void main(String[] args)
{
	ArrayList<String> playernames = new ArrayList<String>(Arrays.asList("Bert","Stijn"));
	gameController gm = new gameController("Big Money",playernames);
	gm.getGame().getPlayerSession().getPlayer(0).getPlayerDiscardDeck().printDeck();
	gm.getGame().getPlayerSession().getPlayer(0).updatePurchases(2);
	gm.playTurn(gm.getGame().getPlayerSession().getPlayer(0));
	gm.playTurn(gm.getGame().getPlayerSession().getPlayer(0));
	
	
	
}



}

