package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class MainGame {
	private DatabaseHelper b;
	private ArrayList<String> voorraad;
	private VoorraadBuild v;
	private ArrayList<String> gameModes;
	private String chosenGameMode;
	private PlayerSession p;
	private ArrayList<Card> playCardsOnField;
	private CardFunctions cf;
	private ArrayList<Card> cardsToShow;
	private ArrayList<Card> trashPile;
	private CardFunctions f;
	
	
	
	
	public MainGame(String chosenGameMode,ArrayList<String> spelersNamen)
	{//gekozen 
		b = new DatabaseHelper();
		voorraad = b.SelectCardsMatchingChosenDeck(chosenGameMode); //dit alleen als men een vast deck kiest, zoniet moet de arraylist met de gekozen kaarten meegegeven
		//worden met constructor die de kaarten bevat die een speler gekozen heeft, gecre�erd;
		v = new VoorraadBuild(voorraad,b,spelersNamen.size());
		setup(spelersNamen);
		
		
		
	}
	public MainGame(ArrayList<String> gekozenKaarten,ArrayList<String> spelersNamen)
	{
		b = new DatabaseHelper();
		
		voegGekozenKaartenToeAanLijst(gekozenKaarten);
		v = new VoorraadBuild(voorraad,b,spelersNamen.size());
		setup(spelersNamen);
		ArrayList<Card> cardsOnPlayField;
		
		
		
	}
	public void setup(ArrayList<String> spelers)
	{

		
		p = new PlayerSession(v,spelers);
		cardsToShow = new ArrayList<Card>();
		trashPile = new ArrayList<Card>();
		playCardsOnField = new ArrayList<Card>();
		f = new CardFunctions(v,p.getSpelersInSpel(), playCardsOnField,cardsToShow,trashPile);
		//kaartenOpVeld = new ArrayList<Card>();
		
	}
	
	public ArrayList<Card> getCardsOnPlayfield()
	{
		return playCardsOnField;
	}
	
	public ArrayList<Card> getCardsToShow()
	{
		return cardsToShow;
	}
	
	public PlayerSession getPlayerSession()
	{
		return p;
	} 
	
	//nodig om arraylist met kaarten te vormen wanneer speler ervoor kiest om z'n deck zelf samen te stellen.
	public void voegGekozenKaartenToeAanLijst(ArrayList<String> gekozenKaarten)
	{
		voorraad = new ArrayList<String>(Arrays.asList("Copper","Silver","Gold","Estate","Duchy","Province"));
		for (int i = 0;i<gekozenKaarten.size();i++)
		{
			voorraad.add(gekozenKaarten.get(i));
		}
	}
	
	
	
	public VoorraadBuild getVoorraadBuild()
	{
		return v;
	}
	public CardFunctions getCardFunctions()
	{
		return f;
	}
	
	public ArrayList<Card> getTrashPile()
	{
		return this.trashPile;
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
	

}
