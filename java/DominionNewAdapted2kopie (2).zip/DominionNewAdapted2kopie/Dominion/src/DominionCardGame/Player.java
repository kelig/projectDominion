package DominionCardGame;

import java.util.*;

public class Player {
	
	private String name;
	private int actions;
	private int purchases;
	private Deck drawDeck;
	private Deck discardDeck;
	private int points;
	private Deck hand;
	private int moneyTurn; //hoeveel dat persoon kan spenderen in 1 beurt
	private VoorraadBuild vb;
	private boolean activePlayer;//boolean die weergeeft of hij/zij aan de beurt is tijdens het spel.
	private boolean vulnerableForAttack;

	public Player(String name,VoorraadBuild v)
	{
		vb = v;
		this.name = name;
		this.drawDeck = new Deck();
		this.discardDeck = new Deck();
		this.hand = new Deck();
		drawDeck.setupPlayer(v);
		this.vulnerableForAttack = true;
		
		
		this.actions = 0;
		this.purchases = 0;
		this.moneyTurn = 0;
		this.points = getPoints();
		activePlayer = false;
	}
	public void SetMoneyTurn(int money)
	{
		this.moneyTurn = money;
	}
	
	public void SetvulnerableForAttack(boolean choice)
	{
		this.vulnerableForAttack = choice;
	}
	public boolean getvulnerableForAttack()
	{
		return this.vulnerableForAttack;
	}
	
	public boolean getPlayerTurnOrNot()
	{
		return activePlayer;
	}
	
	public void setBuyActions(int buys)
	{
		this.purchases = buys;
	}
	
	public void setActions(int actions)
	{
		this.actions = actions;
	}
	public void addPoints(int points)
	{
		
	}
	
	public int getPoints()
	{
		int points = getPointsInDeck(drawDeck) + getPointsInDeck(hand) + getPointsInDeck(discardDeck);
		
		return points;
	}
	
	public int getPointsInDeck(Deck wishedDeck)
	{
		int points = 0;
		for (int i = 0;i<wishedDeck.getSizeDeck();i++)
		{
			points+=wishedDeck.getCard(i).getPunten();
		}
		return points;
	}
	
	
	public void determineCoinsInHandToSpend()
	{
		for (int i = 0;i<hand.getSizeDeck();i++)
		{
			moneyTurn+=hand.getCard(i).getValue();
		}
	}
	
	public void addCoinsFromCardToPlay(Card treasure)
	{
		this.moneyTurn+= treasure.getExtraCoins();
	}
	public void ControlBuyCard(String Cardname)
	{
		if (activePlayer && purchases > 0){
			if (vb.getVoorraadDeck(Cardname).getStapelVol()){
				int prijsKaart = vb.getVoorraadDeck(Cardname).GetCard().getPrice();
				if (prijsKaart <= this.moneyTurn)
				{
					//System.out.println(this.actions);
					discardDeck.BuyCards(Cardname,vb);
					//spelerAP(0,-1);
					//updatePurchases(-1);
					this.purchases--; //fout want purchases verminderen niet bij kopen van kaart
					this.moneyTurn-=prijsKaart;
					
					
					
				}
				else
				{
					System.out.println("Srry but the card costs more money than you have in your hand,please choose another one!");
				}
			
				
						}
		}
		/*else if(activePlayer && purchases > 0 && Cardname == "Copper")//nieuwe tak ,want speler kan koper verkrijgen als hij nog purchases over heeft, maar geen coins meer.
		{
			drawDeck.BuyCards("Copper",vb);
			//updatePurchases(-1);
			this.purchases--;
			
		}*/
		
	}
	
	public int getCoinsToSpend()
	{
		int moneyToSpend = 0;
		for (int i = 0;i<hand.getSizeDeck();i++)
		{
			moneyToSpend+=hand.getCard(i).getValue();
		}
		return moneyToSpend;
	}
	
	public void discardHand()
	{
		for (int i = 0;i<hand.getSizeDeck();i++)
		{
			discardDeck.add(hand.getCard(i));
			
		}
		hand.clear();
	}
	
	public void setSpelerAanZetOfNiet(boolean aanZet)
	{
		activePlayer = aanZet;
	}
	public Deck getPlayerDrawDeck() //vraag speler z'n drawDeck op
	{
		return this.drawDeck;
	}
	
	public Deck getPlayerDiscardDeck() //vraag speler z'n discardDeck op
	{
		return this.discardDeck;
	}
	
	public Deck getPlayerHand() //vraag speler z'n hand op
	{
		return this.hand;
	}
	
	
	public int getActions(){ //kijk hoeveel acties een speler nog over heeft
		
		return this.actions;
	};
	
	public int getPurchases(){ // kijk hoeveel aankopen een speler tijdens een beurt nog kan doen
		
		return this.purchases;
	};
	
	public int getMoneyLeftToSpend() //kijk hoeveel geld een speler tijdens de buyfase nog kan spenderen
	{
		return this.moneyTurn;
	}
	
	
	public String getSpelerNaam() {//vraag de naam vd speler op
		return this.name;
	}
	
	/*public void spelerAP(int Actions, int purchases){ //wanneer een speler een zet doet of iets koopt, zorgt dan dat z'n beschikbare acties en/of te gebruiken aankopen voor die beurt daalt			
		this.actions += Actions;
		this.purchases += purchases;
	}*/
	public void updateActions(int actionUpdate)
	{
		this.actions+=actionUpdate;
	}
	public void updatePurchases(int purchaseUpdate)
	{
		this.purchases+= purchaseUpdate;
	}
	
	
	public void addMoneyToSpend(int money) //vb bij effect van een kaart kan het zijn dat een speler in de buyfase extra geld kan spenderen, dit kan je ophalen uit de databank (kaarten -> ExtraMunten)
	{
		this.moneyTurn+=money;
	}
	
	public void addTo(ArrayList<Card> from,ArrayList<Card> to)
	{
		for (int i = 0;i<from.size();i++)
		{
			Card huidigeKaart = from.get(i);
			to.add(huidigeKaart);
			from.remove(huidigeKaart);
		}
	}
	
	
	
	public void drawCards(int AantalDraw){ //laat een speler kaarten trekken afhankelijk als hij aan beurt is (5 nieuwe) of door effect van kaart er mag trekken (zie database Kaarten -> ExtraKaarten)
		
		//System.out.println("draw cards");
		for(int i = 0; i<AantalDraw; i++){
			int deckSize = drawDeck.getSizeDeck();
			if(deckSize== 0)
			{
				drawDeck = discardDeck;
				discardDeck = null;
				drawDeck.Shuffle();
			}
			Card kaart = drawDeck.getCardOnTop();
			drawDeck.removeTopCard();
			hand.addCard(kaart);
																
		}}
		
	
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			
			
		}
	}
	
	
	

