package Testing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Player;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadBuild;
import DominionCardGame.VoorraadDeck;

public class TestVoorraadDeck {

	private DatabaseHelper d;
	private VoorraadDeck stapelKaartenInVoorraad;
	private Player p1;
	private Player p2;
	private Player p3;
	private Player p4;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenVoorraad;
	private PlayerSession ps;
	private ArrayList<String> spelersNamenInSpel;
	private ArrayList<Player> spelers;
	
	
	public TestVoorraadDeck(int aantalSpelers)
	{
		//spelersNamenInSpel = new ArrayList<String>();
		/*ArrayList<String> mogelijkeSpelers = new ArrayList<String>(Arrays.asList("Karel","Bert","James","Pol"));
		for (int i = 0;i<aantalSpelers;i++)
		{
			spelersNamenInSpel.add(mogelijkeSpelers.get(i));
		}*/
		d = new DatabaseHelper();
		kaartenVoorraad = d.SelectCardsMatchingChosenDeck("Big Money");
		vb = new VoorraadBuild(kaartenVoorraad,d,aantalSpelers);
		//ps = new PlayerSession(vb,spelersNamenInSpel);
		//spelers = ps.getSpelersInSpel();
		
		
		
		/*switch(aantalSpelers)
		{
			case 2:
				spelMet2Spelers();
			break;
			case 3:
				spelMet3Spelers();
			break;
			default:
				spelMet4Spelers();
		}*/
	}
	
	/*public void spelMet2Spelers()
	{
		
		p1 = new Player("Bert",vb);
		p2 = new Player("Stijn",vb);
	}
	public void spelMet3Spelers()
	{
		p1 = new Player("Bert",vb);
		p2 = new Player("Stijn",vb);
		p3 = new Player("Karel",vb);
	}
	public void spelMet4Spelers()
	{
		p1 = new Player("Bert",vb);
		p2 = new Player("Stijn",vb);
		p3 = new Player("Karel",vb);
		p4 = new Player("Pol",vb);
	}*/
	
	public void testVoorraadDeckSpelers(String cardname,int aantalSpelers, int EstateVerwacht,int DuchyProvinceVerwacht,int CurseVerwacht, int kaartAantalVerwacht)
	{
		int verwachtAantal = 0;
		int spelers = aantalSpelers;
		switch(cardname)
		{
		case "Estate":
			verwachtAantal = EstateVerwacht;
			break;
		case "Duchy":
			verwachtAantal = DuchyProvinceVerwacht;
			break;
		case "Province":
			verwachtAantal = DuchyProvinceVerwacht;
			break;
		case "Curse":
			verwachtAantal = CurseVerwacht;
			break;
		default:
			verwachtAantal = kaartAantalVerwacht;
			
			
		}
		
		if (vb.getVoorraadDeck(cardname).getAantalKaartenInVoorraad() != verwachtAantal)
		{
			System.out.println(vb.getVoorraadDeck(cardname).getKaartnaam() + " " + vb.getVoorraadDeck(cardname).getAantalKaartenInVoorraad() + " " + verwachtAantal);
			System.out.println("VoorraadAantallen kloppen niet");
		}
	}
	public void testing()
	{
		TestVoorraadDeck tvd = new TestVoorraadDeck(2);
		tvd.testVoorraadDeckSpelers("Estate",2,14,8,10,10);
		tvd.testVoorraadDeckSpelers("Duchy",2,14,8,10,10);
		tvd.testVoorraadDeckSpelers("Province",2,14,8,10,10);
		tvd.testVoorraadDeckSpelers("Curse",2,14,8,10,10);
		tvd.testVoorraadDeckSpelers("Adventurer",2,14,8,10,10);
		TestVoorraadDeck tvd1 = new TestVoorraadDeck(3);
		tvd1.testVoorraadDeckSpelers("Estate",3,21,12,20,10);
		tvd1.testVoorraadDeckSpelers("Duchy",3,21,12,20,10);
		tvd1.testVoorraadDeckSpelers("Province",3,21,12,20,10);
		tvd1.testVoorraadDeckSpelers("Curse",3,21,12,20,10);
		tvd1.testVoorraadDeckSpelers("Adventurer",3,21,12,20,10);
		TestVoorraadDeck tvd2 = new TestVoorraadDeck(4);
		tvd2.testVoorraadDeckSpelers("Estate",4,24,12,30,10);
		tvd2.testVoorraadDeckSpelers("Duchy",4,24,12,30,10);
		tvd2.testVoorraadDeckSpelers("Province",4,24,12,30,10);
		tvd2.testVoorraadDeckSpelers("Curse",4,24,12,30,10);
		tvd2.testVoorraadDeckSpelers("Adventurer",4,24,12,30,10);
	}
	
	public static void main(String[] args) {
		
		TestVoorraadDeck t = new TestVoorraadDeck(2);
		t.testing();
		
		
	}

}
