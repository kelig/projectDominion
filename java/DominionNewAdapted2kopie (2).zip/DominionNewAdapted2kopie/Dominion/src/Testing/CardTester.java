package Testing;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.junit.*;

import DominionCardGame.Card;
import DominionCardGame.DatabaseHelper;

public class CardTester {
	private String name;
	private int value;
	private int price;
	private String type;
	private int points;
	private int extraActions;
	private int extraCards;
	private int extraCoins;
	private int extraBuys;
	private boolean isSelected;
	private DatabaseHelper database;
	
	public CardTester()
	{
		
		
		database = new DatabaseHelper();
		checkCardValues();
		
	}
	@Test
	public void checkCardValues()
	{
		name = "Market";
		value = 0; 
		price = 5; //
		type = "Action";
		points = 0;
		extraActions = 1;
		extraCards = 1;
		extraCoins = 1;
		extraBuys = 1;
		isSelected = false;
		
		HashMap<String,String> kaartInfoOpgehaald = database.SelectInfoWithColumnName("*","kaartnaam","kaarten","Market");
		Card Adventurer = new Card("Market",kaartInfoOpgehaald);
		assertEquals(name,Adventurer.getCardname());
		assertEquals(value,Adventurer.getValue());
		assertEquals(price,Adventurer.getPrice());
		assertEquals(type,Adventurer.getType());
		assertEquals(points,Adventurer.getPunten());
		assertEquals(extraActions,Adventurer.getExtraActions());
		assertEquals(extraCards,Adventurer.getExtraCards());
		assertEquals(extraCoins,Adventurer.getExtraCoins());
		assertEquals(extraBuys,Adventurer.getExtraBuys());
		assertEquals(isSelected,Adventurer.getIsSelected());
			
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CardTester c = new CardTester();
		
	}
	
}
