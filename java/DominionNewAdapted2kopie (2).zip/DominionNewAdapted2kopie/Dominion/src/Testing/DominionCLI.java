package Testing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import DominionCardGame.CardFunctions;
import DominionCardGame.DatabaseHelper;
import DominionCardGame.MainGame;
import DominionCardGame.Player;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadDeck;

public class DominionCLI {
	private int numberOfPlayers;
	private ArrayList<String> gameModes;
	private DatabaseHelper b;
	private String chosenGameMode;
	private ArrayList<String> playerNames;
	private MainGame m;
	private CardFunctions cf;
	private PlayerSession ps;
	
	public DominionCLI()
	{
		b = new DatabaseHelper();
		askHowManyPlayers();
		addPlayers(numberOfPlayers);
		askForGameMode();
		m = new MainGame(chosenGameMode,playerNames);
		ps = m.getPlayerSession();
		showVoorraadStapelsMetAantal();
		//cf = new CardFunctions(m.getVoorraadBuild());
	}
	
	public void play()
	{
		for (int i = 0;i<ps.getSpelersInSpel().size();i++)
		{
				Player huidigeSpeler = ps.getSpelersInSpel().get(i);
				huidigeSpeler.setSpelerAanZetOfNiet(true);
				Boolean keepBuying = true;
				Boolean keepPlayingActions = true;
				huidigeSpeler.drawCards(5);
				while (huidigeSpeler.getActions() != 0 && keepPlayingActions == true)
				{
					if (actionPlayOrNot())
					{
						huidigeSpeler.getPlayerHand().printDeck();
						askActionToPlay(huidigeSpeler);
					}
					else
					{
						keepPlayingActions = false;
					}
				}
				while (huidigeSpeler.getPurchases() != 0 && keepBuying == true)	{
					if(buyOrNot())
					{	
						System.out.println(huidigeSpeler.getPurchases());
						huidigeSpeler.ControlBuyCard(askWhichCardToBuy());
					}
					else
					{
						keepBuying = false;
					}	
					
					}
				huidigeSpeler.discardHand();
			}
			
			
			
		}
	
	
	public boolean actionPlayOrNot()
	{
		System.out.println("Do you wanna play an actioncard ? yes or no ?");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		boolean respons = (input.equals("yes"))?true:false;
		return respons;
		
		
	}
	public String askWhichCardToBuy()
	{
		System.out.println("Which card do you wanna buy ?");
		m.getVoorraadBuild().getVoorraad();
		Scanner sc = new Scanner(System.in);
		String card = sc.nextLine();
		return card;
	}

	public boolean buyOrNot()
	{
		System.out.println("Do you wanna buy a card ? yes or no ?");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		boolean respons = (input.equals("yes"))?true:false;
		return respons;
		
		
	}
	public void showVoorraadStapelsMetAantal()
	{
		System.out.println("Volgende kaarten bevinden zich in de voorraad met volgende aantallen:\n");
		Iterator it = m.getVoorraadBuild().getVoorraad().entrySet().iterator();
	    while (it.hasNext()) {
	        HashMap.Entry pair = (HashMap.Entry)it.next();
	        
	        String kaartnaam = pair.getKey().toString();
	        VoorraadDeck v = (VoorraadDeck) pair.getValue();
	        int aantal = v.getAantalKaartenInVoorraad();
	        System.out.println(kaartnaam + " " + aantal);
	        
	        
	}}
	public String askAction()
	{
		System.out.println("Welke actiekaart wenst u te spelen?");
		Scanner input = new Scanner(System.in);
		String action = input.nextLine();
		return action;
	}
	
	
	
	public void askActionToPlay(Player playerOnTurn)
	{
		
			cf.playCard(askAction(),playerOnTurn);
		
		
	}
	public void buyPhase()
	{
		
	}
	
	public void askForGameMode()
	{
		System.out.println("Choose one of the following gameModes");
		gameModes = b.SelectWithoutWhere("modenaam","gamemodes");
		System.out.println(gameModes);
		for (int i =1;i>gameModes.size();i++)
		{
			int cipher = i+1;
			System.out.println(cipher + " " + gameModes.get(i));
		}
		Scanner input = new Scanner(System.in);
		String gamemode = input.nextLine();
		chosenGameMode = gamemode;
		
		
	}
	
	public void askHowManyPlayers()
	{
		System.out.println("Met hoeveel willen jullie spelen?");
		Scanner input = new Scanner(System.in);
		numberOfPlayers = Integer.parseInt(input.nextLine());
	}
	
	public void addPlayers(int aantalSpelers)
	{
		playerNames = new ArrayList<String>();
		System.out.println("Geef jullie naam op aub");
		for(int i = 0;i<aantalSpelers;i++)
		{
			Scanner input = new Scanner(System.in);
			String naamSpeler = input.nextLine();
			playerNames.add(naamSpeler);
			
		}
	}
	
	public static void main(String[] args) 
	{
		DominionCLI d = new DominionCLI();
		d.play();
		d.m.getPlayerSession().getPlayer(0).getPlayerDiscardDeck().printDeck();
		d.m.getPlayerSession().getPlayer(1).getPlayerDiscardDeck().printDeck();
	}
}
