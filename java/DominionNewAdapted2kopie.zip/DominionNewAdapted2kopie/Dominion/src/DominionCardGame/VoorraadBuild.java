package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



public class VoorraadBuild {
	private HashMap<String,VoorraadDeck> voorraad;
	private DatabaseHelper data;

	public VoorraadBuild(ArrayList<String> KaartenInGameMode,DatabaseHelper d,int aantalSpelers)
	{
		data = d;
		voorraad = new HashMap<String,VoorraadDeck>(); //voorraad bijhouden in HashMap : VoorraadDecken per kaart met de naam vd kaart bijhouden)
		configureStock(KaartenInGameMode,aantalSpelers);
		
	}
	public void configureStock(ArrayList<String> kaartenInGameMode,int aantalSpelers)//kaartenMetAantal wordt opgehaald door functie in dataBaseHelper
	{
		
	    for (int i = 0;i<kaartenInGameMode.size();i++) { //in voorraad worden adh van kaarten in het gekozen deck , kaartstapels per kaart aangemaakt
	        
	        this.voorraad.put(kaartenInGameMode.get(i),new VoorraadDeck(kaartenInGameMode.get(i),data,aantalSpelers)); 
	    }}
	    
	    public HashMap<String,VoorraadDeck> getVoorraad() //vraag de voorraadStapel op -> met iterator kan je erdoor gaan
	    {
	    	return voorraad;
	    }
	    public VoorraadDeck getVoorraadDeck(String voorraadNaam) //krijg een stapel van kaarten vd gekozen kaart terug (vb stapel met adventure kaarten in voorraad)
	    {
	    	
	    	return voorraad.get(voorraadNaam);
	    
	    }
	    public int getAantalVoorraadDecks() // kijk hoeveel stapels er in je voorraad zijn (normaal zijn dit 10 action - 3 treasure - 3 victory - 32 empty - 1 trash)
	    {
	    	return voorraad.size();
	    }
	    
	    

	    
	    public static void main(String[] args){ 
	    	
	    }
	}




