package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class gameController {
	private MainGame m;
	private int emptyPiles;



	public gameController(String deckname,ArrayList<String> playernames)
	{
		m = new MainGame(deckname,playernames);
		emptyPiles = 0;
		
	}
	
	public void printVoorraad(HashMap<String,VoorraadDeck> voorraad)
	{
		//Iterator it = new Iterator();
	}
	public void play()
	{
		//System.out.println(m.getVoorraadBuild().getVoorraad());
		int i = 0;
		while (emptyPiles < 3 || m.getVoorraadBuild().getVoorraadDeck("Province").getStapelVol() == true)
		{//zolang geen 3 lege koopstapels of stapel province kaarten leeg is, blijf je spelen
			playTurn(m.getPlayerSession().getSpelersInSpel().get(i));
			i++;
			if (i  == m.getPlayerSession().getSpelersInSpel().size()) i = 0;
			
		}
	}
public void playTurn(Player current)
{
	current.updateActions(1); //speler krijgt ��n actie
	current.updatePurchases(1); // speler krijgt ��n koopactie.
	current.setSpelerAanZetOfNiet(true); //speler is nu aan zet
	Boolean keepBuying = true; //speler kan nu kopen
	Boolean keepPlayingActions = true; //speler kan nu actie doen
	current.drawCards(5); //speler trekt vijf nieuwe kaarten
	current.determineCoinsInHandToSpend(); //bepaal coins die men kan spenderen door values van kaarten in hand op te tellen, van actioncards is dit nul, van treasures niet
	current.getPlayerHand().printDeck(); //toon hand vd speler
	while (current.getActions() != 0 && keepPlayingActions == true) 
	{
		if (YesOrNoTurnBuyAction("Do you wanna play an actioncard ? yes or no ?")) //ftie die vraagt met input of je een actiekaart wil spelen of niet
		{
			Card toPlay = current.getPlayerHand().getCardWithName(WhichCardToPlayBuy("play"));
			current.getPlayerHand().remove(toPlay);
			m.getCardFunctions().playCard(toPlay.getCardname(), current);
		}
		else
		{
			keepPlayingActions = false;
		}
	}
	current.getPlayerHand().printDeck();
	while (current.getPurchases() != 0 && keepBuying == true)	{
		System.out.println("You can still spend " + current.getMoneyLeftToSpend() +  " coins!");
		if(YesOrNoTurnBuyAction("Do you wanna buy a card ? yes or no ?"))
		{
			String buy = WhichCardToPlayBuy("buy");
			current.ControlBuyCard(buy);
			if (!m.getVoorraadBuild().getVoorraadDeck(buy).getStapelVol())
			{
				emptyPiles++;
			}
			
		}
		else
		{
			keepBuying = false;
		}	
		
		}
	current.discardHand(); //discard je hand, kaarten gaan naar discardDeck
	current.setBuyActions(0);
	current.setActions(0);
}

public boolean YesOrNoTurnBuyAction(String message)
{
	System.out.println(message);
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	boolean respons = (input.equals("yes"))?true:false; //als gebruiker "yes" antwoord
	//dan is respons = true, anders is respons = false;
	return respons;
	
	
}

public String WhichCardToPlayBuy(String actionBuy)
{
	System.out.println("Which card do you wanna " + actionBuy + " ?");
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	return input;	
}

public MainGame getGame()
{
	return m; 
}

public static void main(String[] args)
{
	ArrayList<String> playernames = new ArrayList<String>(Arrays.asList("Bert","Stijn"));
	gameController gm = new gameController("Size Distortion",playernames);
	Card cellar = gm.getGame().getVoorraadBuild().getVoorraadDeck("Cellar").GetCard();
	gm.getGame().getPlayerSession().getPlayer(0).getPlayerDrawDeck().add(cellar);
	//gm.getGame().getPlayerSession().getPlayer(0).getPlayerDiscardDeck().printDeck();
	//gm.getGame().getPlayerSession().getPlayer(0).updatePurchases(2);
	//gm.playTurn(gm.getGame().getPlayerSession().getPlayer(0));
	//gm.playTurn(gm.getGame().getPlayerSession().getPlayer(0));
	//gm.getGame().getPlayerSession().getPlayer(0).getPlayerDiscardDeck().printDeck();;
	gm.play();
	
	
	
	
}



}

