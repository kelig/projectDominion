package DominionCardGame;

import java.util.ArrayList;
import java.util.HashMap;

public class VoorraadDeck {
	private String nameCardsInPile;
	private int aantal;
	private Card cardConstructor;
	private boolean stapelVol;
	
	private HashMap<String,String> cardInfo;
	public VoorraadDeck(String nameCardsInPile,DatabaseHelper database,int aantalSpelers)
	{
		
		cardInfo = database.SelectInfoWithColumnName("*", "kaartnaam", "kaarten", nameCardsInPile);
		//vraag info vd kaart op waarvan je een stapel in de voorraad wil aanmaken, waarvan je dus later van kan kopen
		this.nameCardsInPile = nameCardsInPile;
		this.aantal = determineAantalKaarten(aantalSpelers,nameCardsInPile);
		this.cardConstructor = new Card(nameCardsInPile,cardInfo);
		this.stapelVol = true;
		
		
		
	}
	
	public int determineAantalKaarten(int aantalSpelers,String cardname)
	{
		//bepaal afh van aantal speler aantal kaarten die per stapel moeten zijn, voor enkelen is er een uitzondering, voor anderen vindt je de waarde in de databank
		int aantalKaartenInVoorraad = 0;
		
	    	switch(cardname)
	    	{
	    		case "Estate":
	    			aantalKaartenInVoorraad = (aantalSpelers > 2)?(aantalSpelers*3+12):(aantalSpelers*3+8);
	    			/*switch(aantalSpelers)
	    			{
	    				
	    				case 2: aantalKaartenInVoorraad = (aantalSpelers*3 + 8);
	    				break;
	    				default: aantalKaartenInVoorraad = aantalSpelers*3 + 12;
	    				
	    				
	    			}*/
	    			break;
	    			
	    		case "Duchy":
	    			aantalKaartenInVoorraad = (aantalSpelers > 2)?12:8;
	    			/*switch(aantalSpelers){
    				
	    				case 2: aantalKaartenInVoorraad = 8;
	    				break;
	    				default: aantalKaartenInVoorraad = 12;
    				
		    			}*/
	    			break;
	    			
	    		case "Province":
	    			aantalKaartenInVoorraad = (aantalSpelers > 2)?12:8;
	    			/*switch(aantalSpelers){
	    				
	    				case 2: aantalKaartenInVoorraad = 8;
	    				break;
	    				default: aantalKaartenInVoorraad = 12;
	    				
			    			}*/
	    			break;
	    			
	    		case "Curse":
	    			aantalKaartenInVoorraad = (aantalSpelers-1)* 10;
	    			/*switch(aantalSpelers)
	    			{
	    				
	    				case 2: aantalKaartenInVoorraad = 10;
	    				break;
	    				case 3: aantalKaartenInVoorraad = 20;
	    				break;
	    				default: aantalKaartenInVoorraad = 30;
	    				
	    			}*/
	    			break;
	    			
	    		default:
	    			aantalKaartenInVoorraad = Integer.parseInt(cardInfo.get("aantalInVoorraad"));
	    			
	    	}
	    	return aantalKaartenInVoorraad;
	    	}
	
	public Card GetCard()
	{
		return this.cardConstructor;
	}

	
	public String getKaartnaam() // vraag naam van kaarten in een voorraadDeck
	{
		return this.nameCardsInPile;
	}
	
	
	public int getAantalKaartenInVoorraad() //vraag aantal kaarten in voorraadStapel van een bepaalde kaart
	{
		return this.aantal;
	}
	
	public Card getCardConstructor() //bij verwijzing naar een kaart, gaat het aantal keer dat die kaart kan gekocht/naar verwezen worden met ��ntje omlaag
	{
		this.aantal-=1;
		if (aantal == 0)
		{
			stapelVol = false;
		}
		return this.cardConstructor;
	}
	
	public boolean getStapelVol() //kijk of er nog kaarten in een stapel van een bepaalde kaart in de voorraad al dan niet leeg is.
	{
		return this.stapelVol;
	}
	public void setStapelVol(boolean choice)
	{
		this.stapelVol = choice;
	}
	
	public static void main(String[] args)
	{
		
	}
}
