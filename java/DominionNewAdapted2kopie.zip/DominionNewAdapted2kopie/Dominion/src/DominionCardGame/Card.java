package DominionCardGame;

import java.util.ArrayList;
import java.util.HashMap;

public class Card {
			private String cardname;
			private int value;
			private int price;
			private String type;
			private int points;
			private int extraActions;
			private int extraCards;
			private int extraCoins;
			private int extraBuys;
			private boolean isSelected;
			
			
			
			
			public Card(String kaartnaam, HashMap<String,String> kaartInfo) { //kaartInfo bevat info over kaart in combinatie met de kolomnamen
				
				this.cardname = kaartnaam;
				this.price = Integer.parseInt(kaartInfo.get("prijs"));
				this.value = Integer.parseInt(kaartInfo.get("waarde"));//is info die uit de databank opgehaald moet worden
				this.type = kaartInfo.get("kaarttype");//is info die uit de databank opgehaald moet worden
				// price,value,type -> is info die uit de databank opgehaald moet worden, deze wordt meegegven 
									 //vanuit VoorraadDeck waar deze info is opgevraagd
				this.points = Integer.parseInt(kaartInfo.get("punten"));
				this.extraActions = Integer.parseInt(kaartInfo.get("extraActies"));//kaart kan ervoor zorgen dat speler extra acties mag doen
				this.extraCoins = Integer.parseInt(kaartInfo.get("extraMunten"));//kaart kan ervoor zorgen dat speler extra munten mag uitgeven in de buyPhase.
				this.extraCards = Integer.parseInt(kaartInfo.get("extraKaarten"));//kaart kan ervoor zorgen dat speler extra kaarten mag trekken
				this.extraBuys = Integer.parseInt(kaartInfo.get("extraBuys"));//kaart kan ervoor zorgen dat speler extra kaarten mag kopen
				this.isSelected = false;
			}
			
			public boolean isSelected() //kijken of kaart geselecteerd is.
			{
				return this.isSelected;
			}
			public void selectCardOrNOt(boolean select) //kaart selecteren of deselecteren
			{
				this.isSelected = select;
			}
			public int getExtraActions()
			{
				return this.extraActions;
			}
			public int getExtraCoins()
			{
				return this.extraCoins;
			}
			public int getExtraCards()
			{
				return this.extraCards;
			}
			public int getExtraBuys()
			{
				return this.extraBuys;
			}
			public String getCardname()
			{
				return this.cardname;
			}
			
			public int getValue()
			{
				return this.value;
			}
			
			public int getPrice()
			{
				return this.price;
			}
			
			public String getType()
			{
				return this.type;
			}
			public int getPunten()
			{
				return this.points;
			}
			
			

			
		};