package Testing;

import DominionCardGame.CardFunctions;
import DominionCardGame.DatabaseHelper;
import DominionCardGame.MainGame;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadBuild;

public class MainTester {
	private CardTester ct;
	private checkPlayerSession cps;
	private DeckTester dt;
	
	private TestBuy tb;
	private TestDataBaseHelper tdbh;
	private TestPlayer tp;
	private TestVoorraadDeck tvd;
	private MainGame mg;
	
	
	public MainTester(int numberPlayers)
	{
		
		ct = new CardTester();
		cps = new checkPlayerSession();
		dt = new DeckTester(numberPlayers);
		tb = new TestBuy();
		tdbh = new TestDataBaseHelper();
		tp = new TestPlayer(numberPlayers);
		tvd = new TestVoorraadDeck(numberPlayers);
		tvd.testing();
	}
	
	
	public static void main(String[] args) 
	{
		MainTester mt = new MainTester(2);
		MainTester mt1 = new MainTester(3);
		MainTester mt2 = new MainTester(4);
	}
	
	
}
