package Testing;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.Player;
import DominionCardGame.VoorraadBuild;

public class TestPlayer {
	private Player p1;
	private Player p2;
	private Player p3;
	private Player p4;
	private VoorraadBuild v;
	private DatabaseHelper d;
	private ArrayList<String> cardsInGamemode;
	private String namePlayer1;
	private int actionsPlayer1;
	private int purchasesPlayer1;
	private Deck drawDeckPlayer1;
	private Deck discardDeckPlayer1;
	//private Hand hand;
	private Deck handPlayer1;
	private int moneyTurnPlayer1; //hoeveel dat persoon kan spenderen in 1 beurt
	private boolean aanZetPlayer1;
	private int oorspronkelijkAantalEstateKaarten;
	private int oorspronkelijkAantalCopperKaarten;
	
	public TestPlayer(int NumberOfPlayers)
	{
		setup(NumberOfPlayers);
		
	}
	
	
	public void checkName()
	{
		
			assertEquals(this.namePlayer1,p1.getSpelerNaam());
		
	}
	
	public void checkDecks(Deck verwachtDeck,Deck deckPlayer)
	{
		assertEquals(verwachtDeck.getDeck(),deckPlayer.getDeck());
		
	}
	
	public void checkNumberValues(int verwachtGetal,int playerGetal)
	{
		assertEquals(verwachtGetal,playerGetal);
		
	}
	
	public void checkSetupPlayer()
	{
		
	}
	public void setup(int NumberOfPlayers){
		d = new DatabaseHelper();
		cardsInGamemode = d.SelectCardsMatchingChosenDeck("Big Money");
		v = new VoorraadBuild(cardsInGamemode,d,NumberOfPlayers);
		oorspronkelijkAantalEstateKaarten = v.getVoorraadDeck("Estate").getAantalKaartenInVoorraad();
		oorspronkelijkAantalCopperKaarten = v.getVoorraadDeck("Copper").getAantalKaartenInVoorraad();
		setupPlayers(NumberOfPlayers);
		
		
		
		this.namePlayer1 = "Bert";
		this.drawDeckPlayer1 = new Deck();
		this.discardDeckPlayer1 = new Deck();
		this.handPlayer1 = new Deck();
		
		
		
		
		this.actionsPlayer1 = 0;
		this.purchasesPlayer1 = 0;
		this.moneyTurnPlayer1 = 0;
		this.aanZetPlayer1 = false;
		
		
	}
	
	public void setupPlayers(int NumberOfPlayers)
	{
		switch(NumberOfPlayers)
		{
		case 2:
			p1 = new Player("Bert",v);
			p2 = new Player("Stijn",v);
			
			break;
		case 3:
			p1 = new Player("Bert",v);
			p2 = new Player("Stijn",v);
			p3 = new Player("Luc",v);
			
			break;
		default:
			p1 = new Player("Bert",v);
			p2 = new Player("Stijn",v);
			p3 = new Player("Luc",v);
			p4 = new Player("Jens",v);
			break;
		}
	}
	
	
	public void testSetupPlayers(int numberOfPlayers)
	{
		
		
		
		
		if ((v.getVoorraadDeck("Estate").getAantalKaartenInVoorraad() != oorspronkelijkAantalEstateKaarten - (3*numberOfPlayers) ) && (v.getVoorraadDeck("Copper").getAantalKaartenInVoorraad() != oorspronkelijkAantalEstateKaarten - (7*numberOfPlayers) ))
		{
			
			
			System.out.println("Kaarten uit voorraad toewijzen aan hand speler werkt niet");
		}
		
		
	}
	@Test
	public void testDrawNormal()
	{
		Player pt = new Player("Dimi",v);
		pt.discardHand();
		assertEquals(10,pt.getPlayerDrawDeck().getSizeDeck());
		assertEquals(0,pt.getPlayerHand().getSizeDeck());
		pt.drawCards(3);
		assertEquals(3,pt.getPlayerHand().getSizeDeck());
		assertEquals(7,pt.getPlayerDrawDeck().getSizeDeck());
		
	}
	
	@Test
	public void testDrawNotEnoughCardsInDrawDeck()
	{
		Player pt = new Player("Dimi",v);
		pt.discardHand();
		pt.getPlayerDiscardDeck().add(v.getVoorraadDeck("Copper").getCardConstructor());
		pt.getPlayerDiscardDeck().add(v.getVoorraadDeck("Copper").getCardConstructor());
		pt.getPlayerDiscardDeck().add(v.getVoorraadDeck("Copper").getCardConstructor());
		pt.getPlayerDrawDeck().clear();
		pt.getPlayerDiscardDeck().add(v.getVoorraadDeck("Estate").getCardConstructor());
		pt.getPlayerDiscardDeck().add(v.getVoorraadDeck("Silver").getCardConstructor());
		assertEquals(0,pt.getPlayerDrawDeck().getSizeDeck());
		assertEquals(0,pt.getPlayerHand().getSizeDeck());
		pt.drawCards(3);
		assertEquals(3,pt.getPlayerHand().getSizeDeck());
		assertEquals(2,pt.getPlayerDrawDeck().getSizeDeck());
		assertEquals(null,pt.getPlayerDiscardDeck());
		
	}
	
	
	
	
	
	
	public void testVoorraadAantalKaartenSoort(int aantalVerwachteKaarten, String cardname)
	{
		int aantalKaartenExpected = aantalVerwachteKaarten;
		if (aantalKaartenExpected != v.getVoorraadDeck(cardname).getAantalKaartenInVoorraad())
		{
			System.out.println(aantalKaartenExpected + " " + v.getVoorraadDeck(cardname).getAantalKaartenInVoorraad() + " "+ cardname);
			System.out.println("aantalKaartenInVoorraad klopt niet met database");
		}
	}
	
	
	
	
	public void TestKaartenInDrawDeck(int verwachteKaarten,int kaartenInDrawDeck)
	{
		
		if (kaartenInDrawDeck !=  verwachteKaarten)
		{
			System.out.println(kaartenInDrawDeck);
			System.out.println("setup werkt niet");
		}
	}
	public void testDeck(String WhichOneDoYouWannaTEest,Deck expectedDeck,Player playerToTest)
	{
		Deck verwachtDeck = null;
		Deck uiteindelijkDeck = null;
		switch(WhichOneDoYouWannaTEest)
		{
		case "DrawDeck":
			verwachtDeck = expectedDeck;
			uiteindelijkDeck = playerToTest.getPlayerDrawDeck();
			break;
		case "DiscardDeck":
			verwachtDeck = expectedDeck;
			uiteindelijkDeck = playerToTest.getPlayerDiscardDeck();
			break;
		case "Hand":
			verwachtDeck = expectedDeck;
			uiteindelijkDeck = playerToTest.getPlayerHand();
			break;
		}
		assertEquals(verwachtDeck,uiteindelijkDeck);
		
		
	}
	public static void PlayerTest(int numberOfPlayers,int expectedCoppers,int expectedEstates,int expectedDuchy,int expectedProvince,int expectedCurses)
	{
		TestPlayer tp = new TestPlayer(numberOfPlayers);
		tp.TestKaartenInDrawDeck(10,tp.p1.getPlayerDrawDeck().getSizeDeck());
		//hier voor 2 spelers
		tp.testVoorraadAantalKaartenSoort(expectedEstates, "Estate");
		tp.testVoorraadAantalKaartenSoort(expectedCoppers, "Copper");
		tp.testVoorraadAantalKaartenSoort(expectedDuchy, "Duchy");
		tp.testVoorraadAantalKaartenSoort(expectedProvince, "Province");
		tp.testVoorraadAantalKaartenSoort(expectedCurses, "Curse");
		
		tp.checkName();
		assertEquals(tp.discardDeckPlayer1.getDeck(),tp.p1.getPlayerDiscardDeck().getDeck());
		tp.discardDeckPlayer1.printDeck();
		tp.p1.getPlayerDiscardDeck().printDeck();
		assertEquals(tp.handPlayer1.getDeck(),tp.p1.getPlayerHand().getDeck());
		tp.checkDecks(tp.discardDeckPlayer1, tp.p1.getPlayerDiscardDeck());
		tp.checkDecks(tp.handPlayer1, tp.p1.getPlayerHand());
		tp.checkNumberValues(tp.moneyTurnPlayer1, tp.p1.getMoneyLeftToSpend());
		tp.checkNumberValues(tp.actionsPlayer1, tp.p1.getActions());
		tp.checkNumberValues(tp.purchasesPlayer1, tp.p1.getPurchases());
		tp.testSetupPlayers(numberOfPlayers);
		assert(false == tp.p1.getPlayerTurnOrNot());
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayerTest(2,46,8,8,8,10);
		PlayerTest(3,39,12,12,12,20);
		PlayerTest(4,32,12,12,12,30);
		TestPlayer tp = new TestPlayer(2);
		tp.testDrawNormal();
		tp.testDrawNotEnoughCardsInDrawDeck();
		
		
		
		
	}
}
