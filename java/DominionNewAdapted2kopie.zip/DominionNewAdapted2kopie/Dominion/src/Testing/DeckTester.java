package Testing;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import DominionCardGame.Card;
import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.VoorraadBuild;

public class DeckTester {
	private Deck testDeck;
	private VoorraadBuild vb;
	private DatabaseHelper d;
	
	public DeckTester(int NumberOfPlayers)
	{
		d = new DatabaseHelper();
		ArrayList<String> chosenCards = d.SelectCardsMatchingChosenDeck("Big Money");
		vb = new VoorraadBuild(chosenCards,d,NumberOfPlayers);
		testDeck = new Deck();
		
	}
	@Test
	public void getTopCardTest()
	{
		testDeck.add(vb.getVoorraadDeck("Gold").getCardConstructor());
		testDeck.add(vb.getVoorraadDeck("Curse").getCardConstructor());
		Card province = vb.getVoorraadDeck("Province").getCardConstructor();
		testDeck.add(province);
		assertEquals("Province",testDeck.getCards().getCardname());
		assertEquals("Curse",testDeck.getCards().getCardname());
		
		
	}
	
	public void getCardByName()
	{
		testDeck.add(vb.getVoorraadDeck("Gold").getCardConstructor());
		testDeck.add(vb.getVoorraadDeck("Curse").getCardConstructor());
		testDeck.add(vb.getVoorraadDeck("Curse").getCardConstructor());
		testDeck.add(vb.getVoorraadDeck("Province").getCardConstructor());
		assertEquals("Curse",testDeck.getCardWithName("Curse").getCardname());
		//testDeck.printDeck();
		
		//assertEquals("Curse",testDeck.getCards().getCardname());
		
		
	}
	
	public void testBuyCards()
	{
		testDeck.add(vb.getVoorraadDeck("Curse").getCardConstructor());
		testDeck.add(vb.getVoorraadDeck("Province").getCardConstructor());
		testDeck.BuyCards("Gold", vb);
		assertEquals("Gold",testDeck.getCard(testDeck.getSizeDeck()-1).getCardname());
	}
	
	
	public static void main(String[] args)
	{
		DeckTester dtr = new DeckTester(2);
		dtr.getTopCardTest();
		dtr.getCardByName();
		dtr.testBuyCards();
	}
	
}
