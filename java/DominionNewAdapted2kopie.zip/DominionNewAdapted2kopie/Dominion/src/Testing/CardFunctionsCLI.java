package Testing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import DominionCardGame.Card;
import DominionCardGame.Deck;
import DominionCardGame.MainGame;
import DominionCardGame.Player;
import DominionCardGame.VoorraadBuild;

public class CardFunctionsCLI {
	private ArrayList<Card> cardsOnField;
	private Player currentPlayer;
	private VoorraadBuild vb;
	private ArrayList<Player> players;
	private ArrayList<Card> cardsToReveal;
	//ms arrayList<Card> voor actionCardsToReveal, VictoryCardsToReveal en TreasureCardsToReveal?????
	private ArrayList<Card> trashPile;
	private Card cardToPlay;

	public CardFunctionsCLI(VoorraadBuild vb,ArrayList<Player> players, ArrayList<Card> cardsOnField,ArrayList<Card> cardsToReveal,ArrayList<Card> trashPile)
	{
		this.vb = vb;
		this.players = players;
		this.cardsOnField = cardsOnField;
		this.cardsToReveal = cardsToReveal;
		this.trashPile = trashPile;
		
	}
	
	public void showCards(Player PlayerNotOnTurn)
	{
		//for (int i = 0;i<spelersNietAanZet;i++)
		//{
			//Player currentPlayerToShowCards = spelersNietAanZet.get(i);
			for (int i = 0;i<PlayerNotOnTurn.getPlayerHand().getSizeDeck();i++)
			{
				cardsToReveal.add(PlayerNotOnTurn.getPlayerHand().getCard(i));
				//hierna wordt arraylist cardsToReveal getoond en erna wordt deze terug leeg gemaakt
				
			}
			cardsToReveal.clear();
			
		//}	
	}
	
	
			
	

	public void playCard(String cardname, Player currentPlayer)
	{
		this.currentPlayer = currentPlayer;
		currentPlayer.getPlayerHand().remove(cardToPlay);
		cardsOnField.add(cardToPlay);
		Card chosen = vb.getVoorraadDeck(cardname).GetCard();
		switch(cardname)
		{
		case "Cellar":
			askToDiscardCards(currentPlayer);
			currentPlayer.updateActions(chosen.getExtraActions());
			
			break;
		case "Chapel":
			
			break;
		case "Workshop":
			break;
		case "Chancellor":
			break;
		case "Village":
			break;
		case "Woodcutter":
			break;
		case "Feast":
			break;
		case "Militia":
			break;
		case "Moneylender":
			break;
		case "Remodel":
			break;
		case "Bureaucrat":
			break;
		case "Smithy":	
			break;
		case "Spy":
			break;
		case "Thief":
			break;
		case "Throne Room":
			break;
		case "Moat":
			break;
		case "Council Room":
			break;
		case "Festival":
			break;
		case "Laboratory":
			break;
		case "Library":
			break;
		case "Market":
			
			break;
		case "Mine":
			break;
		case "Witch":
			break;
		case "Adventurer":
			break;
		case "Gardens":
			break;
		}
	
	cardsOnField.remove(cardToPlay);
	currentPlayer.getPlayerDiscardDeck().add(cardToPlay);
	}
	
		/*public void ActionAdventurer(Player p, Deck gewenstDeckVanTeNemen){
			int revealedTreasureCards = 0;
			for (int i = 0;i<gewenstDeckVanTeNemen.getDeck().size();i++)
			{
				while (revealedTreasureCards < 2)
				{
					if (gewenstDeckVanTeNemen.getCard(gewenstDeckVanTeNemen.size()-1).getType() == "Treasure")
					{
						revealedTreasureCards+=1;
					}
					MainGame.RevealCard(p,gewenstDeckVanTeNemen);
				}
		}
		
	}*/
	//hieronder alle fties van kaarten schrijven
	/*public void BureaucratAction(Player current)
	{
		current.getPlayerDrawDeck().addCard(vb.getVoorraadDeck("Silver").getCardConstructor());
		for (int i = 0;i<players.size();i++)
		{
			Player somePlayer = players.get(i);
			if (somePlayer != current)
			{
				if (somePlayer.getPlayerHand().containsCard("Victory"))
				{
				Card VictoryCardOfSomePlayer = somePlayer.getPlayerHand().getCard("Victory");
				cardsToReveal.add(VictoryCardOfSomePlayer);
				cardsToReveal.remove(VictoryCardOfSomePlayer);
				somePlayer.getPlayerDrawDeck().addCard(VictoryCardOfSomePlayer);
				}
				
			}
			else
			{
				//addCardsTo(AraryList<Card> cardsToReplace,ArrayList<Card> from,ArrayList<Card> to)
				addCardsTo(somePlayer.getPlayerHand(),somePlayer.getPlayerHand(),cardsToReveal);
				addCardsTo(cardsToReveal,cardsToReveal,somePlayer.getPlayerHand());
				cardsToReveal.clear();
				
				
			}
		}
	}*/
	
	public void AdventurerAction(Player current)
	{
		int TreasureCardsRevealed = 0;
		int i = 0;
		Deck playerDrawDeck = current.getPlayerDrawDeck();
		while (TreasureCardsRevealed < 2)
		{
			//Card getrokkenKaart = playerDrawDeck.getCard(playerDrawDeck.getSizeDeck()-i-1);
			Card getrokkenKaart = playerDrawDeck.getCards(); //neem bovenste kaart en verwijder deze uit je drawDeck
			playerDrawDeck.remove(getrokkenKaart);
			if (getrokkenKaart.getType() == "Treasure")
			{
				current.getPlayerHand().add(getrokkenKaart);
			}
			else
			{
				current.getPlayerDiscardDeck().add(getrokkenKaart);
			}
				cardsToReveal.add(getrokkenKaart);
		}
		cardsToReveal.clear();
		
	}
	
	
	public void selectCards(ArrayList<String> selected,Player current)//kaarten die men selecteert worden in arraylist doorgegeven zodat deze ervoor kan zorgen dat ze als geselecteerd aangeduid staan
	{
		for (int i = 0;i<selected.size();i++){
		current.getPlayerHand().getCardWithName(selected.get(i)).selectCardOrNOt(true);
	}}
	public void selectCard(String selected,Player current)
	{
		current.getPlayerHand().getCardWithName(selected).selectCardOrNOt(true);
	}
	
	public void DiscardChosenCard(Card discardCard , Player current)//als de kaart als geselecteerd staat en dus moet gediscarded worden, dan zal dit gebeuren
	{
		if(discardCard.isSelected())
		{
			current.getPlayerDiscardDeck().addCard(discardCard);
			current.drawCards(1);
		}
	}
	
	public void trashChosenCard(Card trashCard , Player current)//als de kaart als geselecteerd staat en dus moet gediscarded worden, dan zal dit gebeuren
	{
		if(trashCard.isSelected())
		{
			trashPile.add(trashCard);
			current.getPlayerHand().remove(trashCard);
		}
	}
	
	public void askToDiscardCards(Player Current)
	{
		for (int i = 0;i<Current.getPlayerHand().getSizeDeck();i++)
		{
			System.out.println(Current.getPlayerHand().getCard(i).getCardname());
			if (askToTrashOrToDiscard())
			{
				selectCard(Current.getPlayerHand().getCard(i).getCardname(),Current);
				trashChosenCard(Current.getPlayerHand().getCard(i),Current);
				Current.drawCards(1);
				
			}
		}
	}
	{
		
	}
	public void CellarAction(Player current,ArrayList<String> toBeDiscarded,Card cellarCard) //kaarten die geslecteerd werden in web, worden met boolean als geselecteerd in de speler zijn hand in java gezet,hierna worden deze gediscarded en neemt speler nieuwe kaarten van zijn drawdeck
	{
		//deze ftie geeft mee aan de server over hoeveel kaarten er beslist moet worden, server zal dan ftie
		//oproepen die speler vraag om het aantal kaarten te kiezen om te discarden afhv hoeveel hij er moet discarden
		//dan server overloopt kaarten en degene die selected zijn , voegt hij toe aan een array die dan naar de java verstuurd wordet
		//waar deze kaarten dan gediscarded worden 
		selectCards(toBeDiscarded,current);
		current.updateActions(cellarCard.getExtraActions());
		for (int i = 0;i<current.getPlayerHand().getSizeDeck();i++)
		{
			DiscardChosenCard(current.getPlayerHand().getCard(i),current);
		}
	}
	
	public void CellarCLIAction(Player current)
	{
		int i = 0;
		int index = 0;
		while(i<current.getPlayerHand().getSizeDeck() && index != -1)
		{
			current.getPlayerHand().printDeck();
			System.out.println("Geef een kaart op die u wil trashen of type 'stop' om te stoppen");
			Scanner sc = new Scanner(System.in);
			String cardname = sc.nextLine();
			index = current.getPlayerHand().searchCardIndex(cardname) ;
			if (index != -1)
			{
				selectCard(cardname,current);
				trashChosenCard(current.getPlayerHand().getCard(index),current);
				
			
		}}
	}
	//server - html - javascript
	/*ftie oproepen die speler aanmaant om kaarten te selecteren.
	 * wanneer speler op kaart klikt, wordt de name tag (kaartnaam) vd kaart waarop 
	 * geklikt is doorgestuurd naar de server
	 * zolang i < kaartenInHandSpeler en knop einde-actie niet ingedrukt is (hier niet index -1 want, bij klikken op kaart ,zal de naam vd kaart altijd voorkomen in de speler zijn hand
	 * , want kaart waar op geklikt is , komt uit de hand vd speler
	 * wordt de kaart getrasht, uit hand van speler gegooid en op trashpile gesmeten
	 */
	
	/*public void trashAantal(Player current, int aantal)
	{
		int i = 0;
		int index = 0;
		int aantalgetrasht = 0;
		while(i<current.getPlayerHand().getSizeDeck() && index != -1 && aantalgetrasht != aantal)
		{
			current.getPlayerHand().printDeck();
			System.out.println("Geef een kaart op die u wil trashen of type 'stop' om te stoppen");
			Scanner sc = new Scanner(System.in);
			String cardname = sc.nextLine();
			index = current.getPlayerHand().searchCardIndex(cardname) ;
			if (index != -1)
			{
				selectCard(cardname,current);
				trashChosenCard(current.getPlayerHand().getCard(index),current);
				aantalgetrasht++;
				
			
		}}
	}*/
	
	public void ChancellorAction(Player current)
	{
		current.addMoneyToSpend(2);
		for (int i = 0;i<current.getPlayerDrawDeck().getSizeDeck();i++)
		{
			Card cardToAdd = current.getPlayerDrawDeck().getCard(i);
			current.getPlayerDrawDeck().remove(cardToAdd);
			current.getPlayerDiscardDeck().add(cardToAdd);
		}
		
	}
	
	public void ChapelAction(Card selectedCard,Player current,ArrayList<String> toBeTrashed)
	{
		selectCards(toBeTrashed,current);
		trashPile.add(selectedCard);
		current.getPlayerHand().remove(selectedCard);
		for (int i = 0;i<current.getPlayerHand().getSizeDeck();i++)
		{
			trashChosenCard(current.getPlayerHand().getCard(i),current);
		}
	}
	
	public void CouncilRoomAction(Player current,Card councilRoom)
	{
		int cardsToDraw = councilRoom.getExtraCards();
		current.drawCards(cardsToDraw);
		current.updatePurchases(councilRoom.getExtraBuys());
		for (int i = 0; players.get(i) != current;i++)
		{
			players.get(i).drawCards(1);
		}
			
	}
	
	/*public void drawCards(Player current,int numberDraw)
	{ 
		current.drawCards(numberDraw);															
	}*/
	
	public void FeastAction(Player current,String cardToBuy)
	{
		//trashPile.add(current.getPlayerHand().getCardWithName("Feast"));
		trashPile.add(cardToPlay);
		int priceCardToBuy = vb.getVoorraadDeck(cardToBuy).GetCard().getPrice();
		if ( priceCardToBuy <= 5)
		{
			current.SetMoneyTurn(priceCardToBuy);
			current.ControlBuyCard(cardToBuy);
		}	
	}
	
	public void FestivalAction(Player current,Card festivalCard)
	{
		
		current.updateActions(festivalCard.getExtraActions());
		current.updatePurchases(festivalCard.getExtraBuys());
		current.addCoinsFromCardToPlay(festivalCard);
	}
	
	
	
	public void buyCard(String cardname,Player current)
	{
		current.ControlBuyCard(cardname);
	}
	
	
	
	public void MineAction(Card cardToBuy, Card cardToTrash,Player current)
	{
		int priceTrashCard = cardToTrash.getPrice();
		if (cardToBuy.getPrice() <= current.getMoneyLeftToSpend() + priceTrashCard)
		{
			current.addMoneyToSpend(priceTrashCard);
			current.ControlBuyCard(cardToBuy.getCardname());
		}
	}
	
	public void GardensAction(Player current)
	{
		int cards = 0;
		for (int i = 0;i<current.getPlayerDiscardDeck().getSizeDeck();i++)
		{
			cards+=1;
		}
		for (int i = 0;i<current.getPlayerDrawDeck().getSizeDeck();i++)
		{
			cards+=1;
		}
		for (int i = 0;i<current.getPlayerHand().getSizeDeck();i++)
		{
			cards+=1;
		}
		current.addPoints(cards/10);
		
	}
	
	public void LaboratoryAction(Player current,Card LaboratoryCard)
	{
		current.drawCards(LaboratoryCard.getExtraCards());
		current.updateActions(LaboratoryCard.getExtraActions());
	}
	
	
	public void LibraryAction(Player current,ArrayList<String> toDiscard)
	{
		while (current.getPlayerHand().getSizeDeck() < 7)
		{
			current.drawCards(1);//deze while loop moet buiten de ftie staan
		}
		
		selectCards(toDiscard,current);
		for (int i = 0;i<current.getPlayerHand().getSizeDeck();i++)
		{
			DiscardChosenCard(current.getPlayerHand().getCard(i),current);
		}
		
		
	}
	
	public boolean askToDiscard(Card toDiscard)
	{
		System.out.println("You wanna discard this card?");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		boolean choiceYesOrNo = (input == "yes")?true:false;
		return choiceYesOrNo;
	}
	
	public void askCardsToDiscard(int count,Player current)
	{
		int discardedCards = 0;
		Deck playerHand = current.getPlayerHand(); 
		while (discardedCards < count){
		for (int i = 0;i<playerHand.getSizeDeck();i++)
		{
			 
			Card discard = playerHand.getCard(i);
			boolean ToDiscard = askToDiscard(discard);
			if (ToDiscard == true)
			{
				playerHand.remove(discard);
				current.getPlayerDiscardDeck().addCard(discard);
				discardedCards++;
			}
		}}
	}
	public void MarketAction(Player current, Card Market)
	{
		current.drawCards(Market.getExtraCards());
		current.updateActions(Market.getExtraActions());
		current.updatePurchases(Market.getExtraBuys());
		current.addMoneyToSpend(1);
	}
	
	public void MilitiaAction(Player current)
	{
		for (int i = 0;players.get(i) != current && players.get(i).getvulnerableForAttack() == true;i++)
		{
			askCardsToDiscard(3,players.get(i));
		}
	}
	public void MineAction(Player current,String cardToTrash,String chosenToBuy )
	{
		askCardsToTrash(1,current);
		Card cardToBuy  = vb.getVoorraadDeck(chosenToBuy).GetCard(); 
		int priceBuyCard = cardToBuy.getPrice();
		if(priceBuyCard <= (current.getMoneyLeftToSpend()+3))
		{
			
			current.ControlBuyCard(chosenToBuy);
		}
		
		
	}
	
	
	public void askCardsToTrash(int aantal,Player current)//vraag een kaart om te trashen en voeg de prijs vd kaart toe aan het geld dat speler kan gebruiken om andere kaart te kopen 
	{
		for (int i = 0;i<aantal;i++)
		{
			String cardname = askCard();
			selectCard(cardname,current);
			Card trashCard = vb.getVoorraadDeck(cardname).GetCard();
			trashChosenCard(trashCard,current);
			current.addMoneyToSpend(trashCard.getPrice());
		}
	}
	
	public String askCard()
	{
		System.out.println("selecteer een kaart");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		return input;
		
	}
	
	public void MoatAction(Player current, Card Moat)
	{
		current.drawCards(Moat.getExtraCards());
		current.SetvulnerableForAttack(false);
	}
	
	public void MoneyLenderActions(Player current,Card MoneyLender)
	{
		selectCard("Copper",current);
		trashChosenCard(vb.getVoorraadDeck("Copper").GetCard(),current);
		current.addMoneyToSpend(MoneyLender.getExtraCoins());
		
		
		
	}
	
	public void RemodelAction(Player current,String cardToTrash,String chosenToBuy )
	{
		askCardsToTrash(1,current);
		Card cardToBuy  = vb.getVoorraadDeck(chosenToBuy).GetCard(); 
		int priceBuyCard = cardToBuy.getPrice();
		if(priceBuyCard <= (current.getMoneyLeftToSpend()+2))
		{
			
			current.ControlBuyCard(chosenToBuy);
		}}
	public void SmithyAction(Player current, Card smithy)
	{
		current.drawCards(smithy.getExtraCards());
	}
	public void VillageAction(Player current,Card village)
	{
		current.drawCards(village.getExtraCards());
		current.updateActions(village.getExtraActions());
	}
	
	public void SpyAction(Player current,Card spy)
	{
		current.drawCards(spy.getExtraCards());
		current.updateActions(spy.getExtraActions());
		for (int i = 0;i<players.size();i++)
		{
			Player currentPlayerToReveal = players.get(i);
			Card topCardDrawDeck = currentPlayerToReveal.getPlayerDrawDeck().getCardOnTop();
			cardsToReveal.add(topCardDrawDeck);
			selectCard(topCardDrawDeck.getCardname(),currentPlayerToReveal);
			if(askToTrashOrToDiscard() == true)
			{
				trashChosenCard(topCardDrawDeck,currentPlayerToReveal);
				
			}
			else
			{
				DiscardChosenCard(topCardDrawDeck,currentPlayerToReveal);
			}
		}
		
	}
	
	public void askToTrash(int amountToTrash,Player current)
	{
		int alreadyTrashed = 0;
		
		int sizeDeck = current.getPlayerHand().getSizeDeck();
		for (int i = 0;i<current.getPlayerHand().getSizeDeck();i++){
			int StillToTrash = amountToTrash - alreadyTrashed;
			if ((alreadyTrashed < amountToTrash) && alreadyTrashed != sizeDeck - alreadyTrashed){
				if (current.getPlayerHand().getSizeDeck() <= StillToTrash)
				{
					//trash de kaart gewoon
				}
				else
				{
					if(askToTrashOrToDiscard() == true)
					{
						trashChosenCard(current.getPlayerHand().getCard(i),current);
					}
				}
				
				
				
		
		
		
	}}}
	
	
	public boolean askToTrashOrToDiscard()
	{
		System.out.println("Do you wanna trash this card ?");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		boolean trashDiscard = (input == "trash")?true:false;
		return trashDiscard;
	}
	
	public boolean askToKeepCard()
	{
		System.out.println("Do you wanna keep this card ?");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		boolean keepCard = (input == "keep")?true:false;
		return keepCard;
	}
	
	public void ThiefAction(Player current)
	{
		for (int i = 0; i<players.size() && players.get(i) != current;i++)
		{
			int numberDiscarded = 0;
			for (int y = 0;y<2;y++)
			{
				Card drawnCard = players.get(i).getPlayerDrawDeck().getCards();
				cardsToReveal.add(drawnCard);
				if (drawnCard.getType() == "Treasure" && numberDiscarded < 1 && askToTrashOrToDiscard())
				{
					//trashPile.add(drawnCard);
					if (askToKeepCard() == true)
					{
						current.getPlayerDiscardDeck().add(drawnCard);
					}
				}
				else
				{
					players.get(i).getPlayerDiscardDeck().add(drawnCard);
				}
				
			}
			
			
		}
	}
	
	
	
	
		
	public void ThroneRoomAction(Player current,String actionCardToPlayTwice)
	{
		for (int i = 0;i<2;i++)
		{
			playCard(actionCardToPlayTwice,current);
		}
		
	}
	
	public void WitchAction(Player current, Card witch)
	{
		current.drawCards(witch.getExtraCards());
		for (int i = 0; i<players.size() && players.get(i) != current;i++)
		{
			players.get(i).getPlayerDiscardDeck().add(vb.getVoorraadDeck("Curse").getCardConstructor());
		}
		
	}
	
	public void WoodcutterAction(Player current, Card woodcutter)
	{
		current.updateActions(woodcutter.getExtraBuys());
		current.addMoneyToSpend(woodcutter.getExtraCoins());
	}
	
	public String chooseCardToBuy()
	{
		//System.out.println("Choose a card costing up to 4 coins to get");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		return input;
		
	}
	public void WorkShopAction(Player current/*,chooseCardToBuy()eig meegeven via de html-javascript-server bij klikken op kaart in voorraad, maar voor console toepassingen zal dit zo verwerkt worden*/)
	{
		String cardToGetName = chooseCardToBuy();
		Card cardToGet = vb.getVoorraadDeck(cardToGetName).GetCard();
		if (cardToGet.getPrice() <= 4)
		{
			current.addMoneyToSpend(cardToGet.getPrice());
			current.ControlBuyCard(cardToGetName);
		}
		
	}
	
	public static void main(String[] args) 
	{
		String deckChosen = "Interaction";
		ArrayList<String> playerNames = new ArrayList(Arrays.asList("Bert","John"));
		MainGame m = new MainGame(deckChosen,playerNames);
		CardFunctionsCLI cf = new CardFunctionsCLI(m.getVoorraadBuild(),m.getPlayerSession().getSpelersInSpel(),m.getCardsOnPlayfield(),m.getCardsToShow(),m.getTrashPile());
		System.out.println(m.getPlayerSession().getSpelersInSpel());
		Player Bert = m.getPlayerSession().getPlayer(0);
		Bert.getPlayerHand().addCard(m.getVoorraadBuild().getVoorraadDeck("Spy").GetCard());
		Bert.getPlayerHand().printDeck();
		cf.SpyAction(Bert, m.getVoorraadBuild().getVoorraadDeck("Spy").GetCard());
		
	}
	
	
	
	
	
	
	
	
		
	
}