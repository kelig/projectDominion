package Testing;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadBuild;

public class checkPlayerSession {

	private PlayerSession ps;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenInMode;
	private DatabaseHelper d;
	private ArrayList<String> spelers;
	
	public checkPlayerSession()
	{
		setup();
		
	}
	public void setup()
	{
		d = new DatabaseHelper();
		kaartenInMode = new ArrayList<String>(Arrays.asList("Adventurer","Bureaucrat","Copper","Estate"));//estate en copper moeten er zeker in ,omdat deze in drawDeck spelers gezet worden bij setup van speler
		vb = new VoorraadBuild(kaartenInMode,d,2);
		spelers = new ArrayList<String>(Arrays.asList("Bert","Kevin","Thomas"));
		ps = new PlayerSession(vb,spelers);
		
		
	}
	
	@Test
	public void checkCreatePlayers(/*ArrayList<String> verwachteSpelers*/)
	{
		ArrayList<String> verwachteSpelers = new ArrayList<String>(Arrays.asList("Bert","Kevin","Thomas"));
		
		assertEquals(3,ps.getSpelersInSpel().size());
		
		for (int i = 0;i<verwachteSpelers.size();i++)
		{
			assertEquals(verwachteSpelers.get(i),ps.getSpelersInSpel().get(i).getSpelerNaam());
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkPlayerSession cps = new checkPlayerSession();
		
		cps.checkCreatePlayers();
		
}}
