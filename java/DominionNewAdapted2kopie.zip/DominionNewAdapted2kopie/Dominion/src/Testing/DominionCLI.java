package Testing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import DominionCardGame.Card;
import DominionCardGame.CardFunctions;
import DominionCardGame.DatabaseHelper;
import DominionCardGame.MainGame;
import DominionCardGame.Player;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadDeck;

public class DominionCLI {
	private int numberOfPlayers;
	private ArrayList<String> gameModes;
	private DatabaseHelper b;
	private String chosenGameMode;
	private ArrayList<String> playerNames;
	private MainGameCLI m;
	private CardFunctionsCLI cf;
	private PlayerSession ps;
	private int emptyPiles;
	
	public DominionCLI()
	{
		b = new DatabaseHelper();
		askHowManyPlayers();
		addPlayers(numberOfPlayers);
		askForGameMode();
		m = new MainGameCLI(chosenGameMode,playerNames);
		ps = m.getPlayerSession();
		showVoorraadStapelsMetAantal();
		emptyPiles = 0;
		play();
		
		//cf = new CardFunctions(m.getVoorraadBuild());
	}
	
	public void play()
	{
		//System.out.println(m.getVoorraadBuild().getVoorraad());
		int i = 0;
		while (emptyPiles < 3 || m.getVoorraadBuild().getVoorraadDeck("Province").getStapelVol() == true)
		{
			playTurn(m.getPlayerSession().getSpelersInSpel().get(i));
			i++;
			if (i  == m.getPlayerSession().getSpelersInSpel().size()) i = 0;
			
		}
		determineWinner(m.getPlayerSession().getSpelersInSpel());
	}
	
	public ArrayList<Player> determineWinner(ArrayList<Player> players)
	{
		int HighestPoints = 0;
		ArrayList<Player> winner = new ArrayList<Player>();;
		for (int i = 0;i<players.size();i++)
		{
			if (players.get(i).getPoints() > HighestPoints)
			{
				winner.clear();
				winner.add(players.get(i));
			}
			else if (players.get(i).getPoints() == HighestPoints)
			{
				winner.add(players.get(i));
			}
		}
		return winner;
	}
public void playTurn(Player current)
{
	current.updateActions(1);
	current.updatePurchases(1);
	current.setSpelerAanZetOfNiet(true);
	Boolean keepBuying = true;
	Boolean keepPlayingActions = true;
	current.drawCards(5);
	current.determineCoinsInHandToSpend();
	System.out.println("Player "+current.getSpelerNaam()+", this is your hand!");
	current.getPlayerHand().printDeck();
	while (current.getActions() != 0 && keepPlayingActions == true)
	{
		if (YesOrNoTurnBuyAction("Do you wanna play an actioncard ? yes or no ?"))
		{
			Card toPlay = current.getPlayerHand().getCardWithName(WhichCardToPlayBuy("play"));
			current.getPlayerHand().remove(toPlay);
			m.getCardFunctions().playCard(toPlay.getCardname(), current);
		}
		else
		{
			keepPlayingActions = false;
		}
	}
	current.getPlayerHand().printDeck();
	while (current.getPurchases() != 0 && keepBuying == true)	{
		System.out.println("You can still spend " + current.getMoneyLeftToSpend() +  " coins!");
		if(YesOrNoTurnBuyAction("Do you wanna buy a card ? yes or no ?"))
		{
			String buy = WhichCardToPlayBuy("buy");
			current.ControlBuyCard(buy);
			if (!m.getVoorraadBuild().getVoorraadDeck(buy).getStapelVol())
			{
				emptyPiles++;
			}
			
		}
		else
		{
			keepBuying = false;
		}	
		
		}
	current.discardHand();
	current.setBuyActions(0);
	current.setActions(0);
	System.out.println();
}



public boolean YesOrNoTurnBuyAction(String message)
{
	System.out.println(message);
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	boolean respons = (input.equals("yes"))?true:false;
	return respons;
	
	
}

public String WhichCardToPlayBuy(String actionBuy)
{
	System.out.println("Which card do you wanna " + actionBuy + " ?");
	Scanner sc = new Scanner(System.in);
	String input = sc.nextLine();
	return input;	
}

public MainGameCLI getGame()
{
	return m; 
}

	public void showVoorraadStapelsMetAantal()
	{
		System.out.println("Volgende kaarten bevinden zich in de voorraad met volgende aantallen:\n");
		Iterator it = m.getVoorraadBuild().getVoorraad().entrySet().iterator();
	    while (it.hasNext()) {
	        HashMap.Entry pair = (HashMap.Entry)it.next();
	        
	        String kaartnaam = pair.getKey().toString();
	        VoorraadDeck v = (VoorraadDeck) pair.getValue();
	        int aantal = v.getAantalKaartenInVoorraad();
	        System.out.println(kaartnaam + " => " + aantal + " kaarten");
	        
	        
	        
	}
	    System.out.println();}
	
	
	
	public void askForGameMode()
	{
		System.out.println("Choose one of the following gameModes");
		gameModes = b.SelectWithoutWhere("modenaam","gamemodes");
		System.out.println(gameModes);
		for (int i =1;i>gameModes.size();i++)
		{
			int cipher = i+1;
			System.out.println(cipher + " " + gameModes.get(i));
		}
		Scanner input = new Scanner(System.in);
		String gamemode = input.nextLine();
		chosenGameMode = gamemode;
		
		
	}
	
	public void askHowManyPlayers()
	{
		System.out.println("Met hoeveel willen jullie spelen?");
		Scanner input = new Scanner(System.in);
		numberOfPlayers = Integer.parseInt(input.nextLine());
	}
	
	public void addPlayers(int aantalSpelers)
	{
		playerNames = new ArrayList<String>();
		System.out.println("Geef jullie naam op aub");
		for(int i = 0;i<aantalSpelers;i++)
		{
			Scanner input = new Scanner(System.in);
			String naamSpeler = input.nextLine();
			playerNames.add(naamSpeler);
			
		}
	}
	
	public static void main(String[] args) 
	{
		DominionCLI d = new DominionCLI();
		//d.play();
		//d.m.getPlayerSession().getPlayer(0).getPlayerDiscardDeck().printDeck();
		//d.m.getPlayerSession().getPlayer(1).getPlayerDiscardDeck().printDeck();
	}
}
