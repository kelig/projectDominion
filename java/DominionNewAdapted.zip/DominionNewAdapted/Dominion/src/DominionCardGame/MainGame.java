package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class MainGame {
	private DatabaseHelper b;
	private ArrayList<String> voorraad;
	private VoorraadBuild v;
	private ArrayList<String> gameModes;
	private String chosenGameMode;
	private PlayerSession p;
	
	
	
	public MainGame(String chosenGameMode,ArrayList<String> spelersNamen)
	{//gekozen 
		b = new DatabaseHelper();
		//askForGameMode();
		voorraad = b.SelectCardsMatchingChosenDeck(chosenGameMode); //dit alleen als men een vast deck kiest, zoniet moet de arraylist met de gekozen kaarten meegegeven
		//worden met constructor die de kaarten bevat die een speler gekozen heeft;
		v = new VoorraadBuild(voorraad,b);
		PlayerSession p = new PlayerSession(v,spelersNamen);
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> spelersNamen = new ArrayList<String>(Arrays.asList("Bert","Karel"));
		MainGame m = new MainGame("Big Money",spelersNamen);
		System.out.println(m.voorraad);
		m.v = new VoorraadBuild(m.voorraad,m.b);
		//m.getCardsInVoorraad();
	}
	
	

}
