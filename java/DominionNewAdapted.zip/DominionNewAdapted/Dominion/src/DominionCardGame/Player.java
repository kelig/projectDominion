package DominionCardGame;

import java.util.*;

public class Player {
	
	private String name;
	private int actions;
	private int purchases;
	private Deck drawDeck;
	private Deck discardDeck;
	//private Hand hand;
	private Deck hand;
	private int moneyTurn; //hoeveel dat persoon kan spenderen in 1 beurt
	

	public Player(String name,VoorraadBuild v)
	{
		
		this.name = name;
		this.drawDeck = new Deck();
		this.discardDeck = new Deck();
		this.hand = new Deck();
		setupPlayer(v);
		
		
		this.actions = 1;
		this.purchases = 1;
		this.moneyTurn = 0;
	}
	
	
	
	public Deck getPlayerDrawDeck() //vraag speler z'n drawDeck op
	{
		return this.drawDeck;
	}
	
	public Deck getPlayerDiscardDeck() //vraag speler z'n discardDeck op
	{
		return this.discardDeck;
	}
	
	public Deck getPlayerHand() //vraag speler z'n hand op
	{
		return this.hand;
	}
	
	
	public int getActions(){ //kijk hoeveel acties een speler nog over heeft
		
		return this.actions;
	};
	
	public int getPurchases(){ // kijk hoeveel aankopen een speler tijdens een beurt nog kan doen
		
		return this.purchases;
	};
	
	public int getMoneyLeftToSpend() //kijk hoeveel geld een speler tijdens de buyfase nog kan spenderen
	{
		return this.moneyTurn;
	}
	
	
	public String getSpelerNaam() {//vraag de naam vd speler op
		return this.name;
	}
	
	public void spelerAP(int Actions, int purchases){ //wanneer een speler een zet doet of iets koopt, zorgt dan dat z'n beschikbare acties en/of te gebruiken aankopen voor die beurt daalt			
		this.actions += Actions;
		this.purchases += purchases;
	}
	
	public void addMoneyToSpend(int money) //vb bij effect van een kaart kan het zijn dat een speler in de buyfase extra geld kan spenderen, dit kan je ophalen uit de databank (kaarten -> ExtraMunten)
	{
		this.moneyTurn+=money;
	}
	
	
	
	public void drawCards(int AantalDraw){ //laat een speler kaarten trekken afhankelijk als hij aan beurt is (5 nieuwe) of door effect van kaart er mag trekken (zie database Kaarten -> ExtraKaarten)
		
		System.out.println("draw cards");
		for(int i = 0; i<AantalDraw; i++){
			if(drawDeck.getSizeDeck()== 0)
			{
				drawDeck = discardDeck;
				discardDeck = null;
				drawDeck.Shuffle();
			}
			Card kaart = drawDeck.getCard(i);
			//hand.addToHand(kaart);
			//drawDeck.remove(i);
			hand.addCard(kaart);
			drawDeck.RemoveCard(i);
																
		}}
		public void setupPlayer(VoorraadBuild v) //bij aanmaken speler krijgt hij bij start van spel 7 copper en 3 estate kaarten in z'n drawDeck
		{
			for(int y =0; y<7;y++){
				
				
				drawDeck.addCard(v.getVoorraadDeck("Copper").getCardConstructor());
		
			}
			for(int z =0; z<3;z++){
		
		
				drawDeck.addCard(v.getVoorraadDeck("Estate").getCardConstructor());
		}
			drawDeck.Shuffle();
	}	
	
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			DatabaseHelper d = new DatabaseHelper();
			ArrayList<String> kaarten = d.SelectCardsMatchingChosenDeck("Big Money");
			VoorraadBuild vb = new VoorraadBuild(kaarten,d);
			System.out.println("aantal kaarten Estate in voorraad = " + vb.getVoorraadDeck("Estate").getAantalKaartenInVoorraad());
			Player p = new Player("Bert",vb);
			System.out.println("Bert heeft "+ p.getPlayerDrawDeck().getSizeDeck()+" kaarten in z'n drawDeck");
			p.getPlayerDrawDeck().printDeck();
			System.out.println("aantal kaarten Estate in voorraad = " + vb.getVoorraadDeck("Estate").getAantalKaartenInVoorraad());
			Player p1 = new Player("Stijn",vb);
			System.out.println("aantal kaarten Estate in voorraad = " + vb.getVoorraadDeck("Estate").getAantalKaartenInVoorraad());
			System.out.println("Stijn heeft "+p1.getPlayerDrawDeck().getSizeDeck()+" kaarten in z'n drawDeck");
			p1.getPlayerDrawDeck().printDeck();
			
		}
	}
	
	
	

