package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PlayerSession {
	
	//private ArrayList<String> spelersNamen;
	private HashMap<String,Integer> voorraad;
	//private int aantalSpelers;
	private ArrayList<Player> players;
	private String chosenGameMode;
	private ArrayList<String> kaartenChosenGameMode;
	private VoorraadBuild v;
	private ArrayList<String> spelersNamen;
	

	
	
	
	public PlayerSession(VoorraadBuild vb,/*, int aantalSpelers*/ ArrayList<String> namenSpelers)
	{
		v = vb;
		
		
		spelersNamen = namenSpelers;
		createPlayers(spelersNamen);		
		
		
		
	}
	
	
	
	public ArrayList<String> getSpelersNamen() // vraag spelersNamen op
	{
		return spelersNamen;
	}
	
	public ArrayList<Player>getSpelersInSpel() //vraag de Player objecten van alle spelers op
	{
		return players;
	}
	
	public void createPlayers(ArrayList<String> namenSpelers)//hierin komt ArrayList<String> spelersNamen; //maak adh van de namen in NamenSpelers, spelersObjecten aan
	{
		players = new ArrayList<Player>();
		for (int i = 0;i<namenSpelers.size();i++)
		{
			
			players.add(new Player(namenSpelers.get(i),v));
		}
		
	}
	

	}


