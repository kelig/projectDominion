package DominionCardGame;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	private ArrayList<Card> deck;
	
	public Deck()
	{
		deck = new ArrayList<Card>();
	}


	public Card getCards()
	{
		int decksize = deck.size();
		Card teReturnenKaart = deck.get(decksize);
		deck.remove(decksize);
		return teReturnenKaart;
		
	}
	public void addCard(Card CardToAdd) //voeg kaart toe aan deck
	{
		deck.add(CardToAdd);
	}
	
	public int getSizeDeck() //vraag lengte van deck op
	{
		return deck.size();
	}
	public void Shuffle() // shuffle je deck
	{
		Collections.shuffle(deck);
	}
	public Card getCard(int index) //vraag een kaart uit je deck op die zich op een bepaalde index in je deck bevind,te gebruiken bij drawCards om laatste kaart op te vragen
	{
		return deck.get(index);
	}
	
	public void RemoveCard(int index)//verwijder kaart uit deck, gebruikt om na draw cards ,wanneer kaart aan hand is toegevoegd, om deze uit je drawdeck te verwijderen
	{// verwijzing naar kaart in voorraad verleg je van vb je drawDeck naar je hand.
		deck.remove(index);
	}
	
	
	public void printDeck() // druk kaarten uit je deck af
	{
		for (int i=0;i<deck.size();i++)
		{
			System.out.print(deck.get(i)/*.getCardname()*/+" = ");
			System.out.println(deck.get(i).getCardname());
		}
		System.out.println();
	}
	
}
