package DominionCardGame;

import java.util.ArrayList;
import java.util.HashMap;

public class Card {
			private String kaartnaam;
			private int VALUE;
			private int price;
			private String TYPE;
			private int Punten;
			
			
			
			
			public Card(String cardname, HashMap<String,String> kaartInfo) { //kaartInfo bevat info over kaart in combinatie met de kolomnamen
				
				this.kaartnaam = cardname;
				this.price = Integer.parseInt(kaartInfo.get("price"));
				this.VALUE = Integer.parseInt(kaartInfo.get("VALUE"));//is info die uit de databank opgehaald moet worden
				this.TYPE = kaartInfo.get("TYPE");//is info die uit de databank opgehaald moet worden
				// price,value,type -> is info die uit de databank opgehaald moet worden, deze wordt meegegven 
									 //vanuit VoorraadDeck waar deze info is opgevraagd
				this.Punten = Integer.parseInt(kaartInfo.get("Punten"));
			}
			
			
			
			
			public String getCardname()
			{
				return this.kaartnaam;
			}
			
			public int getValue()
			{
				return this.VALUE;
			}
			
			public int getPrice()
			{
				return this.price;
			}
			
			public String getType()
			{
				return this.TYPE;
			}
			public int getPunten()
			{
				return this.Punten;
			}
			
			public void playAction(String cardname)
			{
				switch(cardname)
				{
				
				}
			}
		};