package Testing;

import java.util.ArrayList;
import java.util.Arrays;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.PlayerSession;
import DominionCardGame.VoorraadBuild;

public class checkPlayerSession {

	private PlayerSession ps;
	private VoorraadBuild vb;
	private ArrayList<String> kaartenInMode;
	private DatabaseHelper d;
	private ArrayList<String> spelers;
	
	public checkPlayerSession()
	{
		setup();
		
	}
	public void setup()
	{
		d = new DatabaseHelper();
		kaartenInMode = new ArrayList<String>(Arrays.asList("Adventurer","Bureaucrat","Copper","Estate"));//estate en copper moeten er zeker in ,omdat deze in drawDeck spelers gezet worden bij setup van speler
		vb = new VoorraadBuild(kaartenInMode,d);
		spelers = new ArrayList<String>(Arrays.asList("Bert","Kevin"));
		ps = new PlayerSession(vb,spelers);
		
		
	}
	
	
	public void checkCreatePlayers()
	{
		
		
		if (ps.getSpelersInSpel().size() != 2)
		{
			System.out.println("aantal spelers toegevoegd klopt niet");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkPlayerSession cps = new checkPlayerSession();
		
		cps.checkCreatePlayers();
		
}}
