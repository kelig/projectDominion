package Testing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import DominionCardGame.DatabaseHelper;

public class TestDataBaseHelper {

	private HashMap<String,String> verwachteKaartInfo;
	private HashMap<String,String> opgevraagdeKaartInfo;
	private DatabaseHelper data;
	private ArrayList<String> kaartnamen;
	private String[] cards;
	private String modenaam;
	
	public TestDataBaseHelper()
	{
		data = new DatabaseHelper();
	}
	/*public void GetCardInfo(String what,String table,String where,String value)
	{
		
		
		opgevraagdeKaartInfo = data.SelectCardData(what, where, table, value);
		
	}*/
	public void checkSelectCardInfo()
	{
		
		ArrayList<String> kaartInfo = new ArrayList<String>(Arrays.asList("kaartnr","kaartnaam","VALUE","price","TYPE","Punten","ExtraMunten","ExtraKaarten","url","aantalInVoorraad"));
		opgevraagdeKaartInfo = data.SelectInfoWithColumnName("*","kaartnaam","kaarten","Adventurer");
		
		
		
		ArrayList<String> kaartData = new ArrayList<String>(Arrays.asList("1","Adventurer","0","6","Action","0","0","0","","10"));
		
	    for (int i =0;i<kaartInfo.size();i++) {
	    	
	    	if(!opgevraagdeKaartInfo.get(kaartInfo.get(i)).equals(kaartData.get(i)))
	    	{
	    		System.out.println("Fout bij toekenning gegevens aan kaart");
	    	}
	       
	    }
		
		
		
	}
	
	public void verwachteKaartenBijGameMode(String modenaam)
	{
		this.modenaam = modenaam;
		switch(modenaam)
		{
		case "First Game":
			String[] k1 = {"Cellar","Copper","Curse","Duchy","empty","Estate","Gold","Market","Militia","Mine","Moat","Province","Remodel","Silver","Smithy","trash","Village","Woodcutter","Workshop"};
			cards = k1;
			break;
		case "Big Money":
			String[] k2 = {"Adventurer", "Bureaucrat", "Chancellor", "Chapel","Copper","Curse","Duchy","empty","Estate", "Feast",
					"Gold","Laboratory", "Market", "Mine", "Moneylender","Province","Silver", "Throne Room","trash"};
			cards = k2;
			
			break;
		case "Interaction":
			String[] k3 = {"Bureaucrat", "Chancellor","Copper", "Council Room","Curse","Duchy","empty","Estate", "Festival",
					"Gold","Library", "Militia", "Moat","Province","Silver", "Spy", "Thief","trash", "Village"};
			cards = k3;
			break;
		case "Size Distortion":
			String[] k4 = { "Cellar", "Chapel","Copper","Curse","Duchy","empty","Estate", "Feast","Gardens","Gold","Laboratory",
					"Province","Silver","Thief","trash", "Village", "Witch", "Woodcutter", "Workshop"};
			cards = k4;
			break;
		case "Village Square":
			 String[] k5 = {"Bureaucrat", "Cellar","Copper","Curse","Duchy","empty","Estate", "Festival","Gold", "Library", "Market",
					"Province","Remodel","Silver", "Smithy", "Throne Room", "trash","Village", "Woodcutter"};
			cards = k5; 
			break;
		default:
			break;
			
			
		}
		ArrayList<String> kaarten = new ArrayList<String>(Arrays.asList(cards));
		ArrayList<String> kaartenDataBankGameMode = data.SelectCardsMatchingChosenDeck(this.modenaam);
		for (int i = 0;i<kaartenDataBankGameMode.size();i++)
		{
			if (!kaarten.get(i).equals(kaartenDataBankGameMode.get(i)))
			{
				System.out.println(kaarten.get(i)+ " heeft probleem && kaartenBijGameMode werkt niet");
			}
		}
		
	}
		
		
	public void trySelectKaartnamenbijGameMode()
	{
		ArrayList<String> modes = data.SelectWithoutWhere("modenaam","gamemodes");
		for (int i = 0;i<modes.size();i++)
		{
			verwachteKaartenBijGameMode(modes.get(i));
		}
	}
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestDataBaseHelper d = new TestDataBaseHelper();
		d.checkSelectCardInfo();
		d.verwachteKaartenBijGameMode("Big Money");
		d.trySelectKaartnamenbijGameMode();
		
		

}}
