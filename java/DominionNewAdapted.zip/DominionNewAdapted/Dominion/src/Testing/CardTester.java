package Testing;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import DominionCardGame.Card;
import DominionCardGame.DatabaseHelper;

public class CardTester {
	private String name;
	private String value;
	private String price;
	private String type;
	private String points;
	private ArrayList<String> cardInfo;
	private HashMap<String,String> kaartInfo;
	private DatabaseHelper database;
	
	public CardTester()
	{
		
		kaartInfo = new HashMap<String,String>();
		database = new DatabaseHelper();
		checkCardValues();
		
	}
	
	public void checkCardValues()
	{
		name = "Adventurer";
		value = "3"; //bij ophalen omgezet naar intiger met : Integer.parseInt()
		price = "6";; //
		type = "Action";
		points = "0";
		cardInfo = new ArrayList<String>(Arrays.asList(name,value,price,type,points));
		System.out.println(cardInfo);
		kaartInfo.put("points","0");
		kaartInfo.put("TYPE",type);
		kaartInfo.put("price","6");
		kaartInfo.put("VALUE","3");
		kaartInfo.put("kaartnaam",name);
		HashMap<String,String> kaartInfoOpgehaald = database.SelectInfoWithColumnName("*","kaartnaam","kaarten","Adventurer");
		Card Adventurer = new Card("Adventurer",kaartInfoOpgehaald);
		System.out.println(Adventurer.getCardname().equals(kaartInfoOpgehaald.get("kaartnaam")) );
		System.out.println(Adventurer.getPrice() == Integer.parseInt(kaartInfoOpgehaald.get("price")));
		System.out.println(Adventurer.getType().equals(kaartInfoOpgehaald.get("TYPE")) );
		System.out.println(Adventurer.getValue() == Integer.parseInt(kaartInfoOpgehaald.get("VALUE")));
		System.out.println(Adventurer.getPunten() == Integer.parseInt(kaartInfoOpgehaald.get("Punten")));
		System.out.println(kaartInfo);
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CardTester c = new CardTester();
		
	}
	
}
