
public class VictoryCards {
//per actioncard wordt nog eens een aparte klasse gemaakt waarin telkens de specifieke functies van elke kaart staan, er is wel
	//overkoepelende kaart met basisfuncties in bv drawCard en deze wordt via overerving aan de andere actioncards doorgegeven,of gewoon opgeroepen via interfaces.
}
