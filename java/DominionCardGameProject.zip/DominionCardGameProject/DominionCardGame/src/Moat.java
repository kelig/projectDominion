
public class Moat extends Card implements actionPlay  {

	public Moat()
	{
		name = "";//is info die uit de databank opgehaald moet worden
		price = 0;//is info die uit de databank opgehaald moet worden
		value = 0;//is info die uit de databank opgehaald moet worden
		type = "";//is info die uit de databank opgehaald moet worden
		points = 0;//is info die uit de databank opgehaald moet worden
		
	}
	@Override
	public void playAction() {
		// TODO Auto-generated method stub
		
	}

}
