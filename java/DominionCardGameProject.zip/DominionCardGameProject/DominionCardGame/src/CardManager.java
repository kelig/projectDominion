import java.util.HashMap;

public class CardManager {
	public HashMap<String,Object> kaartenMetConstructor;

	public CardManager()
	{
		//public void createCardConstructor()
		//{
			
			kaartenMetConstructor = new HashMap<String,Object>();
			kaartenMetConstructor.put("Adventurer", new Adventurer());
			kaartenMetConstructor.put("Bureaucrat", new Bureaucrat());
			kaartenMetConstructor.put("Cellar", new Cellar());
			kaartenMetConstructor.put("Chancellor", new Chancellor());
			kaartenMetConstructor.put("Chapel", new Chapel());
			kaartenMetConstructor.put("Copper", new Copper());
			kaartenMetConstructor.put("Council Room", new CouncilRoom());
			kaartenMetConstructor.put("Curse", new Curse());
			kaartenMetConstructor.put("Duchy", new Duchy());
			//kaartenMetConstructor.get("uchy")
			kaartenMetConstructor.put("Estate", new Estate());
			kaartenMetConstructor.put("Feast", new Feast());
			kaartenMetConstructor.put("Festival", new Festival());
			kaartenMetConstructor.put("Gardens", new Gardens());
			kaartenMetConstructor.put("Gold", new Gold());
			kaartenMetConstructor.put("Laboratory", new Laboratory());
			kaartenMetConstructor.put("Library", new Library());
			kaartenMetConstructor.put("Market", new Market());
			kaartenMetConstructor.put("Militia", new Militia());
			kaartenMetConstructor.put("Mine", new Mine());
			kaartenMetConstructor.put("Moat", new Moat());
			kaartenMetConstructor.put("Moneylender", new MoneyLender());
			kaartenMetConstructor.put("Province", new Province());
			kaartenMetConstructor.put("Remodel", new Remodel());
			kaartenMetConstructor.put("Silver", new Silver());
			kaartenMetConstructor.put("Smithy", new Smithy());
			kaartenMetConstructor.put("Spy", new Spy());
			kaartenMetConstructor.put("Thief", new Thief());
			kaartenMetConstructor.put("Throne Room", new ThroneRoom());
			kaartenMetConstructor.put("Village", new Village());
			kaartenMetConstructor.put("Witch", new Witch());
			kaartenMetConstructor.put("Woodcutter", new Woodcutter());
			kaartenMetConstructor.put("Workshop", new Workshop());
			
		//}

		
	}
	
	
	
	
	
	
	public Object makeCard(String cardname)
	{
		return kaartenMetConstructor.get(cardname);
	}
}
