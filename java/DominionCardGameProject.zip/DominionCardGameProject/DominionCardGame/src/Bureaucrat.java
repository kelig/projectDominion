
public class Bureaucrat extends Card implements actionPlay {
	
	public Bureaucrat()//db meegeven en fties uit class databasehelper oproepen om name,price,value, type te vullen
	{
		name = "";//is info die uit de databank opgehaald moet worden
		price = 0;//is info die uit de databank opgehaald moet worden
		value = 0;//is info die uit de databank opgehaald moet worden
		type = "";//is info die uit de databank opgehaald moet worden
		points = 0;//is info die uit de databank opgehaald moet worden
		
	}
	
	@Override
	public void playAction() {
		// TODO Auto-generated method stub
		
	}

}
