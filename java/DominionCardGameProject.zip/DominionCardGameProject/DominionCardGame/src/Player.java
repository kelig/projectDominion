
import java.util.*;

	public class Player {
		
		private String name;
		private int actions;
		private int purchases;
		//private ArrayList<Object> drawDeck;
		//private ArrayList<Object> discardDeck;
		//private ArrayList<Object> hand;
		private Deck drawDeck;
		private Deck discardDeck;
		//private Hand hand;
		private Deck hand;
		private int moneyTurn; //hoeveel dat persoon kan spenderen in 1 beurt
		private deckBuild decks;
	
		public Player(String name)
		{
			decks = new deckBuild();
			this.name = name;
			this.drawDeck = new Deck();
			this.discardDeck = new Deck();
			//this.hand = new Hand();
			this.hand = new Deck();
			//this.drawDeck = decks.getDrawDeck();
			//this.discardDeck = decks.getDiscardDeck();
			//this.hand = decks.getHand();
			
			this.actions = 1;
			this.purchases = 1;
			this.moneyTurn = 0;
		}
		//decks.ftieuitdeckBuildDieJeWilOproepen
		
		
		public /*ArrayList<Object>*/ Deck getPlayerDrawDeck()
		{
			return drawDeck;
		}
		
		public /*ArrayList<Object>*/ Deck getPlayerDiscardDeck()
		{
			return discardDeck;
		}
		
		public /*ArrayList<Object>*/ /*Hand*/ Deck getPlayerHand()
		{
			return hand;
		}
		
		/*public deckBuild getDeckBuild()
		{
			return decks;
		}*/
		public int getActions(){
			
			return actions;
		};
		
		public int getPurchases(){
			
			return purchases;
		};
		
		public int getMoneyLeftToSpend()
		{
			return moneyTurn;
		}
		
		
		public String getSpelerNaam() {
			return name;
		}
		
		public void spelerAP(int Actions, int purchases){			
			this.actions += Actions;
			this.purchases += purchases;
		}
		
		public void addMoneyToSpend(int money)
		{
			moneyTurn+=money;
		}
		public void drawCard()
		{
			//hand.addToHand(drawDeck.getCard());
			hand.addCard(drawDeck.getCard());
		}
		public void drawCards(int AantalDraw){
			
			System.out.println("draw cards");
			for(int i = 0; i<AantalDraw; i++){
				if(drawDeck.getSize()== 0)
				{
					drawDeck = discardDeck;
					discardDeck = null;
					drawDeck.Shuffle();;
				}
				Object kaart = drawDeck.getCard(i);
				//hand.addToHand(kaart);
				//drawDeck.remove(i);
				hand.addCard(kaart);
				drawDeck.removeCard(i);
																	
			}}
		public void setupPlayer()
		{
			for(int y =0; y<7;y++){
				
				
				drawDeck.addCard(new Copper());
		
		
			}
			for(int z =0; z<3;z++){
		
		
		drawDeck.addCard(new Estate());
		}
			drawDeck.Shuffle();
	}

}