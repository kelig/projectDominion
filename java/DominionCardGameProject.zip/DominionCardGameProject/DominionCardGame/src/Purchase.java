import java.util.*;

public class Purchase {
	private HashMap<String,Integer> voorraad;
	//private Map<String,Integer> voorraad; //hierin zit de voorraad, wordt aan het begin van het spel afh van welke gamemode gekozen is
	//zullen de actioncards van deze mode hierin komen met hun waarde op 10 alsook de resterende munten en victorypoints die over zijn (victorypoints - reeds uitgedeeld bij setup aan spelers)

	public Purchase(String Cardname,Player spelerAanZet)//speler aan zet wordt automatisch toegevoegd door spel, speler aan zet wordt bijgehouden en hierin opgeroepen met de huidgeSpeler aan zet als dit nodig is, indien deze tijdens z'n beurt iets koopt)
	{
		//PlayerSession.getVoorraad().get(Cardname)--;
		voorraad.put(Cardname,voorraad.get(Cardname) + 1);
		spelerAanZet.getHandArrayList().add(new Card(Cardname));
		//Player(spelerAanZet).getHand.remove(Cardname);
	}
	
	public void createVoorraad(ArrayList<String> chosenActionCards)//ActionCardsGekozenGameMode zal aantallen van gekozen actioncards bij gekozen GameMode
	//in databank reeds op 10 gezet hebben, alle kaarten waar aantal != 0 zullen worden toegevoegd aan de voorraad met hun aantal erbij(van actionCards worden deze op 10 gezet, afh
	//of ze voorkomen in de gekozen GameMode)
	{
		voorraad = new HashMap<String,Integer>();
		for (int i = 0;i</*aantal kaarten in databank waarvan het aantal != 0*/;i++)
		{
			voorraad.put(/*naam vd kaart*/, /*aantal vd kaart in databank reeds voorgedefineerd, of bij actioncards aangepast in databank doordat ze tot de gekozenGameMode behoren*/)
		}
	}
	public HashMap<String,Integer> getVoorraad()
	{
		return voorraad;
	}

	
	
	
	
	
	
	
	
}
	