import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;



public class Testing {
	
	private ArrayList<String> discarded;
	//private static String[] kaartenChosenGamemode = {"Cellar","Market","Militia","Mine","Moat","Remodel","Smithy","Village","Woodcutter","Workshop"};
	private static ArrayList<String> kaartenChosenGameMode =  new ArrayList<String>(Arrays.asList("Cellar","Market","Militia","Mine","Moat","Remodel","Smithy","Village","Woodcutter","Workshop"));
	private static HashMap<String,Integer> voor;
	
	public static void PlayerFunctionTester()
	{
		ArrayList<String> spelers = new ArrayList<String>();
		spelers.add("Hendrik");
		spelers.add("Bert");
		spelers.add("Steven");
		Player p = new Player(spelers.get(1));
		if (p.getSpelerNaam() != "Bert")
		{
			System.out.println("Playerfunctions don't work");
		}
		else
		{
			System.out.println("PlayerFunctions werkt!!");
		}
	}
	public static void voorraadOpbouwTester(/*String[]*/ ArrayList<String> actionCards){
		voorraadClass voorraad = new voorraadClass(2,actionCards);
		//voorraad.VoorraadNumber(2,actionCards);
		if (voorraad.getStartVictory() != 8)
		{
			System.out.println("StartVictory niet in orde");
		}
		if (voorraad.getVoorraad().get("Copper") != 46)
		{
			System.out.println("VoorraadOpbouw werkt niet");
		}
		//if (voorraad.)
		voor = voorraad.getVoorraad();
		String kaartenInMode = "";
		for (HashMap.Entry<String, Integer> entry : voor.entrySet())
		{
		    //System.out.println(entry.getKey() + " = " + entry.getValue() + " kaarten");
			
			kaartenInMode += entry.getKey() + " " ;
			
			
		}
		if (kaartenInMode.toString() !="Gold Militia Estate Cellar Smithy Village Woodcutter Market Province Silver Moat Curse Duchy Mine Remodel Workshop Copper ")
		{
			System.out.println(kaartenInMode.toString());
			System.out.println("Voorraad werkt niet");
		}
	}
	
	

	public static void main(String[] args) {
		//PlayerFunctionTester();
		voorraadOpbouwTester(kaartenChosenGameMode);
		//PlayerSession p = new PlayerSession();
		
		
	
		
		
		
	
		

	}

}
