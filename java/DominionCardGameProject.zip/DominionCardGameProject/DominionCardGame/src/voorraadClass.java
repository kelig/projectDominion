import java.util.ArrayList;
import java.util.HashMap;

public class voorraadClass {
	//private HashMap<String,Integer> voorraad;
	private HashMap<String,Integer> voorraad;
	private ArrayList<String> kaartNamenVanGekozenMode;
	private HashMap<String,Integer> voorraadAantal;
	private int startVictory;
	
	
	public voorraadClass(int aantalSpelers,ArrayList<String> /*String[]*/ gekozenGameModeKaarten)
	{
		//createVoorraad(aantalSpelers,kaartNamenVanGekozenMode);
		System.out.println(gekozenGameModeKaarten);
		VoorraadNumber(aantalSpelers,gekozenGameModeKaarten);
		
		
	}
	/*public void createVoorraad(ArrayList<String> kaartenInGameMode)
	{
		for(int i=0;i<kaartenInGameMode.size();i++);
		{
			voorraad.put(kaartenInGameMode.get(i),10);
		}
	}*/
	
	
	
	//afhankelijk van binengekomen kaartnaam, kan je kaart aan voorraad toevoegen,deze ftie oproepen bij opzetten vd beginvoorraad
	//map bijhouden met kaartnamen en object die erbij aangemaakt wordt.
	//bv map.put("adventurer",createNewAdventureCard => 

	//bij trekken kaart van voorraad, krijg je de naam binnen ,die zoek je op in de legende en de class vd kaart die je wil maken zal aangesproken worden
	//om deze kaart te maken en toe te voegen aan je deck bij kopen ervan;
	
	//bv
	//private HashMap<String,Object> legende;
	//public void pickCardFromVoorraad(String Cardname)// deze functie zal een kaartObject teruggeven afh van de cardBuilder (bv ftie createNewAdventureCard + returned dit kaartObject) die bij de kaartnaam wordt opgeroepen in de legende, deze ftie aanroepen in DeckBuild en daar dan de ftie schrijven om 
	//{//kaartobject aan Deck toe te voegen .bv in Deckbuild ftie => public void addCardToDeck(Object card){deck.add(card)}
		//deck.add(legende.get(Cardname))
		/////////legende.get(Cardname) zorgt dat kaart van gekozen cardname wordt aangemaakt en toegevoegd wordt aan de speler z'n deck
	//}
	
	//public void buyCard(String cardname)
	//{
	
		//cardname opzoeken in legende,kaart zal aangemaakt worden door ftie die bij de cardname in de Map legende staat(vb zie MakeAdventureCard in class Adventurer) en dit kaartobject zal ook teruggeven worden
		//ftie addCardToDeck in DeckBuilder krijgt deze kaart binnen en voegt dit kaartObject toe aan de speler z'n deck;
	//}
		
	
	public void getCardNamesFromChosenGameMode()
	{
		//in databank namen vankaarten horende bij gekozen gameMode toevoegen aan stringArrayList => value,type en price worden bij aanmaken
		//vd kaarten in aparte class opgehaald door de class vd kaart zelf bv class Adventurer haalt die voor zichzelf op afh van de kaartnaam
	}
	
	//public void addResterendeTreasureCards() //aantal treasureCards en victory cards over, na uitdelen 7 kopers en 3 estate aan elke beginspeler

	//aantal kaarten bijhouden in session in Map !!!!!!!,enkel attributen van kaarten (price,type,value,name) opslaan
	//in database, voorraad opslaan in databank bij saven van spel.
	
	//{
		//voorraad = new HashMap<String,Integer>();
		//for (int i = 0;i</*aantal kaarten in databank waarvan het aantal != 0*/;i++)
		//{
			//voorraad.put(/*naam vd kaart*/, /*aantal vd kaart in databank reeds voorgedefineerd, of bij actioncards aangepast in databank doordat ze tot de gekozenGameMode behoren*/)
		//}
	//}
	/*public HashMap<String,Object> getConstructorForCardInVoorraad()
	{
		return 
	}*/
	
	public HashMap<String,Integer> getVoorraad()
	{
		return voorraadAantal;
	}
	
	
	public void VoorraadNumber(int aantalSpelers,/*String[] kaartenInMode*/ArrayList<String> kaartenInMode)
	{
		
		voorraadAantal = new HashMap<String,Integer>();
		voorraadAantal.put("Copper", 60-(aantalSpelers*7));
		voorraadAantal.put("Silver", 30);
		voorraadAantal.put("Gold", 20);
		
		if(aantalSpelers == 2)
		{
			startVictory = 8;	
		}
		else
		{
			startVictory = 12;
		}
		voorraadAantal.put("Estate", startVictory-(aantalSpelers*3));
		voorraadAantal.put("Province",startVictory);
		voorraadAantal.put("Duchy", startVictory);
		voorraadAantal.put("Curse", (aantalSpelers-1)*10);
		
		
		for(int i = 0;i</*kaartenInMode.length*/kaartenInMode.size();i++)
		{
			voorraadAantal.put(/*kaartenInMode[i]*/kaartenInMode.get(i), 10);
		}
	}
	public int getStartVictory()
	{
		return startVictory;
	}
	
	public void buy(String kaart,Player spelerAanZet)
	{
		int aantalKaartenInVoorraad = voorraadAantal.get(kaart);
		if(aantalKaartenInVoorraad > 0)
		//met voorraad wordt hier hashmap<"Adventurer",new Adventurer()> bedoeld
		spelerAanZet.getPlayerDrawDeck().add(kaartVoorraadBuild.makeCard(kaart));
		
		voorraad.put(kaart, aantalKaartenInVoorraad-1);
	}
	
}

