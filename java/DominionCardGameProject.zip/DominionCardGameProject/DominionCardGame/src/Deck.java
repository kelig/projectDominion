import java.util.ArrayList;
import java.util.Collections;

//constructor voor het maken van drawDeck en discardDeck
public class Deck {
	private ArrayList<Object> deck;
	
	public Deck()
	{
		deck = new ArrayList<Object>();
		
	}

	public Object getCard()
	{
		int decksize = deck.size();
		Object teReturnenKaart = deck.get(decksize);
		deck.remove(decksize);
		return teReturnenKaart;
		
	}
	public int getSize()
	{
		return deck.size();
	}
	public void Shuffle()
	{
		Collections.shuffle(deck);
	}
	public Object getCard(int kaartnummer)
	{
		return deck.get(kaartnummer);
	}
	public void removeCard(int kaartnummer)
	{
		deck.remove(kaartnummer);
		
	}
	public void addCard(Object kaart)
	{
		deck.add(kaart);
	}
}
