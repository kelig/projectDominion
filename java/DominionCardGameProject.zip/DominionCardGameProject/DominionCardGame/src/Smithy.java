
public class Smithy extends Card implements actionPlay  {

	@Override
	public void playAction() {
		// TODO Auto-generated method stub
		
	}

}
