import java.lang.*;

public interface actionPlay
{
	
	void playAction();
	
	
}

