import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class deckBuild {
	private ArrayList<Object> hand;
	private ArrayList<Object> drawDeck;
	private ArrayList<Object> discardDeck;
	private ArrayList<Object> cardCreator;
	
	
	public deckBuild()
	{
		
		hand = new ArrayList<Object>();
		drawDeck = new ArrayList<Object>();
		discardDeck = new ArrayList<Object>();
	}
	
	public ArrayList<Object> getHand()
	{
		return hand;
	}
	
	public ArrayList<Object> getDrawDeck()
	{
		return drawDeck;
	}
	
	public ArrayList<Object> getDiscardDeck()
	{
		return discardDeck;
	}
	
	public void addCardToDeck(Object toeTeVoegenKaart)
	{
		drawDeck.add(toeTeVoegenKaart);
	}
	
	public void drawCards(int AantalDraw){
		
		System.out.println("draw cards");
		for(int i = 0; i<AantalDraw; i++){
			if(drawDeck.size()== 0)
			{
				drawDeck = discardDeck;
				discardDeck = null;
				Collections.shuffle(drawDeck);
			}
			Object kaart = drawDeck.get(i);
			hand.add(kaart);
			drawDeck.remove(i);
			
	        
															
		}}
		
			
	public void discardHand(){

	System.out.println("DiscardedHand");

	for(int i= 0; i<hand.size(); i++){
		
		Object kaart = hand.get(i);
		discardDeck.add(kaart);
		
	}
	hand.clear();
				
	}
	
	
	
	
}
