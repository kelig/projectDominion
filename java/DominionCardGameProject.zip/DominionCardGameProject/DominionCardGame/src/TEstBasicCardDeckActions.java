import static org.junit.Assert.*;

import org.junit.Test;

public class TEstBasicCardDeckActions {
	
	private Player p1;
	private PlayerSession p = new PlayerSession();
	
	
	
	public void setup()
	{
		p1 = new Player("Ben");
		p1.setupPlayer();
		
		
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		for (int i = 0;i<)
	}

}
