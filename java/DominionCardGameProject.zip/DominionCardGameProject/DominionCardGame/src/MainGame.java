
public class MainGame {
	private Map<String,Integer> voorraad;
	private ArrayList<Player> spelers;
	private ArrayList<String> spelersNamen;
	private PlayerSession playerSetup;
	
	
	public MainGame()
	{
		spelersNamen = getSpelersNamen()
		playerSetup = new PlayerSession(spelersNamen);
		voorraad = new voorraadClass();
		spelers = new 
	}
	setup(createPlayers(namenSpelers))
}
