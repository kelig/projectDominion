import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Functions {
	ArrayList<Object> deck;
	ArrayList<Object> discarded;
	ArrayList<Object> hand;
	Object getrokkenKaart;
	//Player p = new Player();
	//ArrayList<Player> spelers;
	//ArrayList<String> spelersnamen;


	

public void drawCards(int AantalDraw){
	
	for(int i = 0; i<AantalDraw; i++){
		if(deck.size()== 0)
		{
			deck = discarded;
			discarded = null;
			Collections.shuffle(deck);
		}
		Object kaart = deck.get(i);
		hand.add(kaart);
		deck.remove(i);
		
        System.out.println(kaart.getCardname());
      


        
        
														
	}	
	
}
	public void discardHand(){

		System.out.println("DiscardedHand");

		for(int i= 0; i<hand.size(); i++){
	
			Card kaart = hand.get(i);
			discarded.add(kaart);
	
		}
		hand.clear();
			
		}


	//System.out.println("Discarded size");
	//System.out.println(discarded.size());
	//System.out.println(deck.size());
	
	public Object getCard()
	{
		getrokkenKaart = deck.get(deck.size());
		
	}
	public void discardCard(Object kaart)
	{
		deck.remove(kaart)
		discarded.add(kaart);
	}
	public void RevealTreasureCards()
	{
		int treasureCards = 0;
		for(int i =0;i<deck.size();i++)
		{
			while (treasureCards < 2)
			{
				getCard();
				if (getrokkenKaart.getType() == "treasure")
				{
					
				}
			}
		}
	}
	
	
};	






	
	
	
	
	
	
	
	
	
	
	
}
