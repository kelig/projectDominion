import java.util.ArrayList;

public class Hand {
	private ArrayList<Object> hand;
	
	public Hand()
	{
		hand = new ArrayList<Object>();
	}
	
	public void addToHand(Object kaart)
	{
		hand.add(kaart);
	}

}
