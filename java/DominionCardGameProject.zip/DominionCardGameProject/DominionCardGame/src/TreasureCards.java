
public class TreasureCards /*implements actionPlay*/  {

}
