package DominionCardGame;

import java.util.HashMap;

public class VoorraadDeck {
	private String nameCardsInPile;
	private int aantal;
	private Card cardConstructor;
	private boolean stapelVol;
	public VoorraadDeck(String nameCardsInPile,int aantal)
	{
		this.nameCardsInPile = nameCardsInPile;
		this.aantal = aantal;
		this.cardConstructor = new Card(nameCardsInPile);
		this.stapelVol = true;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
