package DominionCardGame;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	private ArrayList<Card> deck;
	
	public Deck()
	{
		deck = new ArrayList<Card>();
	}


	public Card getCards()
	{
		int decksize = deck.size();
		Card teReturnenKaart = deck.get(decksize);
		deck.remove(decksize);
		return teReturnenKaart;
		
	}
	public void addCard(Card CardToAdd)
	{
		deck.add(CardToAdd);
	}
	
	public int getSizeDeck()
	{
		return deck.size();
	}
	public void Shuffle()
	{
		Collections.shuffle(deck);
	}
	public Card getCard(int index)
	{
		return deck.get(index);
	}
	
	public void RemoveCard(int index)
	{
		deck.remove(index);
	}
	
	public void setupPlayer()
	{
		for(int y =0; y<7;y++){
			
			
			deck.add(new Card("Copper"));
	
	
		}
		for(int z =0; z<3;z++){
	
	
			deck.add(new Card("Estate"));
	}
		Collections.shuffle(deck);
}
	
	public void printDeck()
	{
		for (int i=0;i<deck.size();i++)
		{
			System.out.println(deck.get(i).getCardname());
		}
	}
	
}
