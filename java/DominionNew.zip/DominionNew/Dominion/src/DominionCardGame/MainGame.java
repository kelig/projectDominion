package DominionCardGame;

public class MainGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DatabaseHelper b = new DatabaseHelper();

	}

}
