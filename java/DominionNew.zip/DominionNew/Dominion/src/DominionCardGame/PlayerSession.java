package DominionCardGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PlayerSession {
	
	private ArrayList<String> spelersNamen;
	private HashMap<String,Integer> voorraad;
	private int aantalSpelers;
	private ArrayList<Player> players;
	private String chosenGameMode;
	private ArrayList<String> kaartenChosenGameMode;
	

	
	
	
	public PlayerSession(/*ArrayList<String> namenSpelers*/)
	{
		//fillKaartenChosenGameMode(chooseGameMode());
		
		askHowManyPlayers();
		addPlayers(aantalSpelers);
		createPlayers(spelersNamen);		
		setup(players);
		fillKaartenChosenGameMode();
		//Card kaartenClass = new Card();
		CardManager createCards = new CardManager();//gebruiken bij vb kopen nieuwe kaart en toevoegen aan deck, verwijs je naar deze kaart(
		//(zie implementatie voorraad) vb 30 gold cards in voorraad => max 30 keer verwijzing naar Card('Gold') mogelijk in voorraad
		//voorraadClass voorraadBuilder = new voorraadClass(spelersNamen.size(),kaartenChosenGameMode,kaartenClass);
		
		//createVoorraad(ArrayList<String> gekozenActionCardsInGameMode)
		//voorraadBuilder.makeStartVoorraad(aantalSpelers,kaartenChosenGameMode);
		
	}
	
	public void fillKaartenChosenGameMode(/*String gameMode*/)
	{
		//hardcoded//
		//kaartenChosenGameMode = {};//kaarten ChosenGameMode(actioncards) worden opgehaald met sql statement
		//horende bij gegeven gameMode opvragen en opslaan in arraylist kaartenChosenGameMode
		//for (int i = 0;i<10;i++) mss met prepareStatement,execute() en dan FetchAll
		//{
			kaartenChosenGameMode = new ArrayList<String>(Arrays.asList("Cellar","Market","Militia","Mine","Moat","Remodel","Smithy","Village","Woodcutter","Workshop"));
		//}
		
		
	}
	
		
	/*public void chooseGameMode()
	{
		System.out.println("Volgende gameModes zijn beschikbaar: Big Money,......"(nrmaal weergeven met for loop die deze vanuit databank toont);
		Scanner gameMode = new Scanner(System.in);
		chosenGameMode = gameMode.toString();
	}*/
	
	public void askHowManyPlayers()
	{
		System.out.println("Met hoeveel willen jullie spelen?");
		Scanner input = new Scanner(System.in);
		aantalSpelers = Integer.parseInt(input.nextLine());
	}
	
	
	public void addPlayers(int aantalSpelers)
	{
		spelersNamen = new ArrayList<String>();
		System.out.println("Geef jullie naam op aub");
		for(int i = 0;i<aantalSpelers;i++)
		{
			Scanner input = new Scanner(System.in);
			String naamSpeler = input.nextLine();
			spelersNamen.add(naamSpeler);
			
		}
	}
	public ArrayList<String> getSpelersNamen()
	{
		return spelersNamen;
	}
	
	public ArrayList<Player>getSpelersInSpel()
	{
		return players;
	}
	
	
	
	
	
	
	
	public void createPlayers(ArrayList<String> namenSpelers)//hierin komt ArrayList<String> spelersNamen;
	{
		players = new ArrayList<Player>();
		for (int i = 0;i<namenSpelers.size();i++)
		{
			//System.out.println(namenSpelers.get(i));
			players.add(new Player(namenSpelers.get(i)));
		}
		
	}
	
	public void setup(ArrayList<Player> LijstSpelers){ //hierin komt ArrayList<Player> spelers uit vorige functie createPlayer) {
			
		for(int i = 0;i<LijstSpelers.size();i++)
			{
				
				Player huidigeSpeler = LijstSpelers.get(i);	
				//ArrayList<Card>deck = huidigeSpeler.getDrawDeck();
				huidigeSpeler.getPlayerDrawDeck().setupPlayer();
			}
	
	}
	public void chooseGameMode()
	{
		//gameModes ophalen uit database en in Array steken (vb gameModes)
		//array GameModes overlopen en printen voor gebruiker met indexnummer+1 erbij
		//gebruiker geeft nummer van gameMode op die hij/zij wil gebruiken
		//String chosenGameMode = gameModes.get(i)-1 index voor eerste gameModes ipv nul in array zet je die op ��n voor de gebruiker,
		//maar als hij gameMode 1 kiest, is dit eig gameMode 0 voor de array.
		//eerst gameModes tonen aan gebruiker, daarna kiest gebruiker een mode;
		//chosenGameMode = gameModeDieGebruikerKiest
	}













	}


