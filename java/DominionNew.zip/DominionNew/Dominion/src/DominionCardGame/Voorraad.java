package DominionCardGame;

public class Voorraad {
	//na kopen van kaart controleer je of de voorraad v/e bepaalde kaart op is uit de koopvoorraad, zoja variabele int legeVoorraadStapels +=1
	//adhv legeVoorraadStapels, is dit 3 , dan stopt het spel of als ��n v/d stapels met victorykaarten leeg is.
}
