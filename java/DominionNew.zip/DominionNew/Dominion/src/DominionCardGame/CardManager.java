package DominionCardGame;
import java.util.HashMap;

public class CardManager {
	public HashMap<String,Card> kaartenMetConstructor;

	public CardManager()
	{
		//public void createCardConstructor()
		//{
			
			kaartenMetConstructor = new HashMap<String,Card>();
			kaartenMetConstructor.put("Adventurer", new Card("Adventurer"));
			kaartenMetConstructor.put("Bureaucrat", new Card("Bureaucrat"));
			kaartenMetConstructor.put("Cellar", new Card("Cellar"));
			kaartenMetConstructor.put("Chancellor", new Card("Chancellor"));
			kaartenMetConstructor.put("Chapel", new Card("Chapel"));
			kaartenMetConstructor.put("Copper", new Card("Copper"));
			kaartenMetConstructor.put("Council Room", new Card("Council Room"));
			kaartenMetConstructor.put("Curse", new Card("Curse"));
			kaartenMetConstructor.put("Duchy", new Card("Duchy"));
			//kaartenMetConstructor.get("uchy")
			kaartenMetConstructor.put("Estate", new Card("Estate"));
			kaartenMetConstructor.put("Feast", new Card("Feast"));
			kaartenMetConstructor.put("Festival", new Card("Festival"));
			kaartenMetConstructor.put("Gardens", new Card("Gardens"));
			kaartenMetConstructor.put("Gold", new Card("Gold"));
			kaartenMetConstructor.put("Laboratory",new Card("Laboratory"));
			kaartenMetConstructor.put("Library", new Card("Library"));
			kaartenMetConstructor.put("Market", new Card("Market"));
			kaartenMetConstructor.put("Militia", new Card("Militia"));
			kaartenMetConstructor.put("Mine", new Card("Mine"));
			kaartenMetConstructor.put("Moat", new Card("Moat"));
			kaartenMetConstructor.put("Moneylender", new Card("Moneylender"));
			kaartenMetConstructor.put("Province", new Card("Province"));
			kaartenMetConstructor.put("Remodel", new Card("Remodel"));
			kaartenMetConstructor.put("Silver", new Card("Silver"));
			kaartenMetConstructor.put("Smithy", new Card("Smithy"));
			kaartenMetConstructor.put("Spy", new Card("Spy"));
			kaartenMetConstructor.put("Thief", new Card("Thief"));
			kaartenMetConstructor.put("Throne Room", new Card("Throne Room"));
			kaartenMetConstructor.put("Village", new Card("Village"));
			kaartenMetConstructor.put("Witch", new Card("Witch"));
			kaartenMetConstructor.put("Woodcutter", new Card("Woodcutter"));
			kaartenMetConstructor.put("Workshop", new Card("Workshop"));
			
		//}

		
	}
	
	
	
	
	
	
	public Object makeCard(String cardname)
	{
		return kaartenMetConstructor.get(cardname);
	}
}
