package DominionCardGame;

import java.util.HashMap;

public class Card {
			public String name;
			public int value;
			public int price;
			public String type;
			public int points;
			
			
			
			public Card(String cardname) {
				DatabaseHelper b = new DatabaseHelper();
				this.name = cardname;
				//this.price = 0;//is info die uit de databank opgehaald moet worden
				//this.value = 0;//is info die uit de databank opgehaald moet worden
				//this.type = "";//is info die uit de databank opgehaald moet worden
				
				
			}
			
			
			
			
			public String getCardname()
			{
				return name;
			}
			
			public int getValue()
			{
				return value;
			}
			
			public int getPrice()
			{
				return price;
			}
			
			public String getType()
			{
				return type;
			}
			
			public void playAction(String cardname)
			{
				switch(cardname)
				{
				
				}
			}
		};