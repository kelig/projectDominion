package DominionCardGame;

import java.util.*;

public class Player {
	
	private String name;
	private int actions;
	private int purchases;
	private Deck drawDeck;
	private Deck discardDeck;
	//private Hand hand;
	private Deck hand;
	private int moneyTurn; //hoeveel dat persoon kan spenderen in 1 beurt
	

	public Player(String name)
	{
		
		this.name = name;
		this.drawDeck = new Deck();
		this.discardDeck = new Deck();
		this.hand = new Deck();
		drawDeck.setupPlayer();
		
		
		this.actions = 1;
		this.purchases = 1;
		this.moneyTurn = 0;
	}
	//decks.ftieuitdeckBuildDieJeWilOproepen
	
	
	public /*ArrayList<Object>*/ Deck getPlayerDrawDeck()
	{
		return drawDeck;
	}
	
	public /*ArrayList<Object>*/ Deck getPlayerDiscardDeck()
	{
		return discardDeck;
	}
	
	public /*ArrayList<Object>*/ Deck getPlayerHand()
	{
		return hand;
	}
	
	
	public int getActions(){
		
		return actions;
	};
	
	public int getPurchases(){
		
		return purchases;
	};
	
	public int getMoneyLeftToSpend()
	{
		return moneyTurn;
	}
	
	
	public String getSpelerNaam() {
		return name;
	}
	
	public void spelerAP(int Actions, int purchases){			
		this.actions += Actions;
		this.purchases += purchases;
	}
	
	public void addMoneyToSpend(int money)
	{
		moneyTurn+=money;
	}
	
	
	
	public void drawCards(int AantalDraw){
		
		System.out.println("draw cards");
		for(int i = 0; i<AantalDraw; i++){
			if(drawDeck.getSizeDeck()== 0)
			{
				drawDeck = discardDeck;
				discardDeck = null;
				drawDeck.Shuffle();;
			}
			Card kaart = drawDeck.getCard(i);
			//hand.addToHand(kaart);
			//drawDeck.remove(i);
			hand.addCard(kaart);
			drawDeck.RemoveCard(i);
																
		}}
	
	
	

}