package DominionCardGame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



public class VoorraadBuild {
	private ArrayList<VoorraadDeck> voorraad;

	public VoorraadBuild(HashMap<String,Integer> KaartenInGameMode)
	{
		configureStock(KaartenInGameMode);
	}
	public void configureStock(HashMap<String,Integer> kaartenMetAantal)//kaartenMetAantal wordt opgehaald door functie in dataBaseHelper
	{
		Iterator it = kaartenMetAantal.entrySet().iterator();
	    while (it.hasNext()) {
	        HashMap.Entry pair = (HashMap.Entry)it.next();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
	        voorraad.add(new voorraadDeck(pair.getValue(),pair.getKey()));
	        //it.remove(); // avoids a ConcurrentModificationException
	    }
		
		
		
		
		
		
		
		/*for (String key : kaartenMetAantal.)
		{
			String kaartnaam = "";
			int aantalKaarten = kaartenMetAantal.get(kaartnaam);		
			voorraad.add(new VoorraadDeck(,aantalKaarten));
		}*/
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
