package DominionCardGame;


import java.io.FileInputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.sql.DataSource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;


public class DatabaseHelper {
	private String databaseURL;
	private String user;
	private String password;
	private Connection conn;
	private Statement stmt;
	private String[] result;
	private ArrayList<String> results;
	private HashMap<String,String> results2;
	
	public DatabaseHelper()
	{
		
		getMySQLConnection();
		SelectStatement("*","kaartnr","kaarten","'2'");
		SelectStatement2("*","kaartnr","kaarten","'2'");
		SelectCardsMathingChosenDeck("Big Money"); 
		//String Modenaam = intval(SelectStatement("modenaam","modenr","gamemodes","2",)
		
		}
	public void getMySQLConnection()
	{
		databaseURL = "jdbc:mysql://localhost:3306/Dominion2";
		user = "root";
		password = "";
		conn = null;
        
        try {
  
        	Class.forName("com.mysql.jdbc.Driver");
        	conn = DriverManager.getConnection(databaseURL,user,password);
            if(conn != null)
            {
            	System.out.println("Connected to database");
            }
            
            
        }catch (ClassNotFoundException ex) {
            System.out.println("Could not find database driver class");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        } 
    
        
        
	}
	public void closeConnection()
	{
		if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}

	public String[] SelectStatement(String whatAreYouLookingFor,String WhereStatement,String table,String value) 
	{
		stmt = null;
		results = new ArrayList<String>();
		
	
		String updatedQuery = "SELECT "+whatAreYouLookingFor+" FROM "+table+" WHERE "+WhereStatement +"= "+value;
		//System.out.println(updatedQuery);
		try{
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			while(rs.next())
			{
				
				for (int i = 1;i<rs.getMetaData().getColumnCount();i++)
				{
					results.add(rs.getString(i));
					System.out.print(rs.getString(i) + " ");
				}
				System.out.println();
				
				
			}
			
				
				
			}catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		try
		{
			
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		   
		return result;
	
	
}
	
	public String[] SelectStatement2(String whatDoYouWant,String WhereStatement,String table,String value) 
	{
		stmt = null;
		results2 = new HashMap<String,String>();
		
		
		String updatedQuery = "SELECT "+whatDoYouWant+" FROM "+table+" WHERE "+WhereStatement +"= "+value;
		//.out.println(updatedQuery);
		try{
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			while(rs.next())
			{
				
				for (int i = 1;i<rs.getMetaData().getColumnCount();i++)
				{
					results2.put(rs.getMetaData().getColumnName(i),rs.getString(i));
					System.out.print(rs.getMetaData().getColumnName(i) + " ");
						
					System.out.println(rs.getString(i) + " ");
				}
				
				System.out.println();
				
				
			}
			
				
				
			}catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		
		try
		{
		
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		
		   
		return result;
	
	
}
	
	public String SelectOneElement(String whatDoYouWant,String WhereStatement,String table,String value) 
	{
		stmt = null;
		String result = "";
		
		
		String updatedQuery = "SELECT "+whatDoYouWant+" FROM "+table+" WHERE "+WhereStatement +"= "+value;
		//System.out.println(updatedQuery);
		try{
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			while(rs.next())
			{
				
				for (int i = 1;i<rs.getMetaData().getColumnCount();i++)
				{
					results.add(rs.getString(i));
					System.out.print(rs.getString(i) + " ");
				}
				System.out.println();
				
				
			}
						
					
				}
				
				
				
			
			
				
				
			catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		
		try
		{
		
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		
		   
		return result;
	
	
}
	
	public /*ArrayList<String>*/ HashMap<String,Integer> SelectCardsMathingChosenDeck(/*String gameMode*/ String modenaam) 
	{
		stmt = null;
		//String[] result = new String[10];
		//ArrayList<String> result = new ArrayList<String>();
		HashMap<String,Integer> kaartenInGameModePlusAantalInVorraad = new HashMap<String,Integer>();
		
		//String query ="SELECT modenaam FROM modes WHERE modenr = "+modenr;
		String updatedQuery = "SELECT kaartnaam,aantalInVoorraad FROM kaarten JOIN kaartingamemode ON kaarten.kaartnr= kaartingamemode.kaartnr JOIN gamemodes ON kaartingamemode.modenr = gamemodes.modenr WHERE modenaam = '" + modenaam + "'";
		System.out.println(updatedQuery);
		//System.out.println(updatedQuery);
		try{
			;
			//stmt = conn.createStatement();
			stmt = conn.prepareStatement(updatedQuery);
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			
			while(rs.next())
			{
					//System.out.println(rs.getRow()-2);
					//result.add(rs.getString(1));
					kaartenInGameModePlusAantalInVorraad.put(rs.getString(1),rs.getInt(2));
					System.out.print(rs.getString(1) + "," + rs.getInt(2) + " ");
					System.out.println();
				}
				//System.out.println(result);
				System.out.println();
				
				
			}
						
					
				
				
				
				
			
			
				
				
			catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		
		try
		{
		
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		
		   
		return kaartenInGameModePlusAantalInVorraad;
	
	
}
	
	
	
	public void ShowResult(ArrayList<String> resultaten)
	{
		for (int i = 0;i<resultaten.size();i++)
		{
			System.out.print(resultaten.get(i).toString());
		}
	}
}

