package DominionCardGame;


import java.io.FileInputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.sql.DataSource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;


public class DatabaseHelper {
	private String databaseURL;
	private String user;
	private String password;
	private Connection conn;
	private Statement stmt;
	private String[] result;
	private ArrayList<String> results;
	private HashMap<String,String> results2;
	
	public DatabaseHelper()
	{
		
		//SelectStatement(/*conn,*/"kaartnaam","kaarten");
		//ShowResult(results);
		//SelectStatement(/*conn,*/"*","kaarten");
		SelectStatement("kaartnr","kaarten","'2'"/*,"kaartnr"*/);
		SelectStatement2("kaartnr","kaarten","'2'"/*,"kaartnr"*/);
		
		}
	public void getMySQLConnection()
	{
		databaseURL = "jdbc:mysql://localhost:3306/Dominion";
		user = "root";
		password = "";
		conn = null;
        
        try {
  
        	Class.forName("com.mysql.jdbc.Driver");
        	conn = DriverManager.getConnection(databaseURL,user,password);
            if(conn != null)
            {
            	System.out.println("Connected to database");
            }
            
            
        }catch (ClassNotFoundException ex) {
            System.out.println("Could not find database driver class");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        } 
    
        
        
	}
	public void closeConnection()
	{
		if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}

	public String[] SelectStatement(/*Connection con,*/String WhereStatement,String table/*,String kaartnaam*/,String value/*,String whatAreYouLookingFor*/) 
	{
		stmt = null;
		results = new ArrayList<String>();
		
		//String query = "select "+whatAreYouLookingFor+" from " + table;
		String updatedQuery = "SELECT * FROM "+table+" WHERE "+WhereStatement +"= "+value;
		System.out.println(updatedQuery);
		try{
			getMySQLConnection();
			stmt = /*con*/conn.createStatement();
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			while(rs.next())
			{
				//result = rs.getString(whatAreYouLookingFor);
				for (int i = 1;i<rs.getMetaData().getColumnCount();i++)
				{
					results.add(rs.getString(i));
					System.out.print(rs.getString(i) + " ");
				}
				System.out.println();
				//System.out.println(result);
				
			}
			
				//result = rs.getString(whatAreYouLookingFor);
				//System.out.println(result);
				
			}catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		try
		{
			closeConnection();
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		   
		return result;
	
	
}
	
	public String[] SelectStatement2(/*Connection con,*/String WhereStatement,String table/*,String kaartnaam*/,String value/*,String whatAreYouLookingFor*/) 
	{
		stmt = null;
		results2 = new HashMap<String,String>();
		
		//String query = "select "+whatAreYouLookingFor+" from " + table;
		String updatedQuery = "SELECT * FROM "+table+" WHERE "+WhereStatement +"= "+value;
		System.out.println(updatedQuery);
		try{
			getMySQLConnection();
			stmt = /*con*/conn.createStatement();
			ResultSet rs = stmt.executeQuery(updatedQuery);
			
			while(rs.next())
			{
				//result = rs.getString(whatAreYouLookingFor);
				for (int i = 1;i<rs.getMetaData().getColumnCount();i++)
				{
					results2.put(rs.getMetaData().getColumnName(i),rs.getString(i));
					System.out.print(rs.getMetaData().getColumnName(i) + " ");
						
					System.out.println(rs.getString(i) + " ");
				}
				//System.out.println(results2.get("kaartnr"));
				System.out.println();
				//System.out.println(result);
				
			}
			
				//result = rs.getString(whatAreYouLookingFor);
				//System.out.println(result);
				
			}catch (SQLException e ) {
		        System.out.println(e.getMessage());
		
		}
		try
		{
			closeConnection();
			stmt.close();
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
		   
		return result;
	
	
}
	
	
	public void ShowResult(ArrayList<String> resultaten)
	{
		for (int i = 0;i<resultaten.size();i++)
		{
			System.out.print(resultaten.get(i).toString());
		}
	}
}

