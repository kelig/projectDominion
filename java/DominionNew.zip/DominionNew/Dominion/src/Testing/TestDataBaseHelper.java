package Testing;

import DominionCardGame.DatabaseHelper;

public class TestDataBaseHelper {

	public void setup()
	{
		DatabaseHelper d = new DatabaseHelper();
		String select = "*";
		String from = "kaarten";
		String where = "kaartnr";
		String is = "2";
	}
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
