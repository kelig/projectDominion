package Testing;

import DominionCardGame.DatabaseHelper;
import DominionCardGame.Deck;
import DominionCardGame.Player;

public class TestDeck {
	private static Player p;
	
	public TestDeck()
	{
		p = new Player("Arne");
		//p.getPlayerDrawDeck().printDeck();
		
	}
	public static /*boolean*/ void countCardsWithName(int verwachtAantal,String cardname,Deck deck)
	{
		int huidigAantal = 0;
		//boolean result = false;
		for (int i =0;i<deck.getSizeDeck();i++)
		{
			if (deck.getCard(i).getCardname() == cardname)
			{
				huidigAantal+=1;
			}
		}
		if (huidigAantal == verwachtAantal)
		{
			//result = true;
			
		}
		else
		{
			System.out.println("SetupPlayer werkt niet");
		}
		//return result;
	}
	
	public static void checkLastCard(String kaartnaam,Deck deck)
	{
		String lastCard = deck.getCard(deck.getSizeDeck()).getCardname();
		if (kaartnaam != lastCard)
		{
			System.out.println("AddCardToDeck werkt niet");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestDeck t = new TestDeck();
		/*System.out.println(*/countCardsWithName(3,"Estate",t.p.getPlayerDrawDeck());/*);*/
		/*System.out.println(*/countCardsWithName(7,"Copper",t.p.getPlayerDrawDeck());/*);*/

	}
}
